﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Services
{
    public interface IScrapingService 
    {
        public Task<IEnumerable<object>> GetAllAsync();
    }
}
