﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Services.Uow
{
    public interface IUnitOfWork
    {
        Task<IEnumerable<TEntity>> GetAll<TEntity>(string spName, DynamicParameters parameters = null) where TEntity : class;
    }
}
