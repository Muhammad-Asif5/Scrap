﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace WebApi.Services.Uow
{
    public sealed class UnitOfWork : IUnitOfWork
    {
        private readonly WebApi.Services.ConnectionManager.IDbConnection _context;
        public UnitOfWork(WebApi.Services.ConnectionManager.IDbConnection context)
        {
            _context = context;
        }

        public async Task<IEnumerable<TEntity>> GetAll<TEntity>(string spName, DynamicParameters parameters) where TEntity : class
        {
            try
            {
                using (var sqlCon = _context.CreateConnection())
                {
                    var result = await sqlCon.QueryAsync<TEntity>(spName, parameters, commandType: CommandType.Text);
                    return result.AsList();
                }
            }
            catch (Exception ex)
            {
                return new List<TEntity>();
            }
        }
    }
}
