﻿using Microsoft.Extensions.Configuration;
using Npgsql;

namespace WebApi.Services.ConnectionManager
{
    public interface IDbConnection
    {
        public NpgsqlConnection GetConnection { get; }
        public NpgsqlConnection CreateConnection();

    }
    public class DbConnection : IDbConnection
    {
        private readonly string _connectionString;
        private readonly IConfiguration _configuration;
        public DbConnection(IConfiguration configuration)
        {
            _configuration = configuration;
            _connectionString = _configuration.GetConnectionString("ScrapingDB");
        }
        public NpgsqlConnection CreateConnection() => new NpgsqlConnection(_connectionString);
        public NpgsqlConnection GetConnection
        {
            get
            {
                return new NpgsqlConnection(_connectionString);
            }
        }
    }
}
