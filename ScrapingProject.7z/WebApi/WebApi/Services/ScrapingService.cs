﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using WebApi.Services.Uow;

namespace WebApi.Services
{
    public class ScrapingService : IScrapingService
    {
        private readonly IUnitOfWork unitOfWork;
        public ScrapingService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }
        public async Task<IEnumerable<Object>> GetAllAsync()
        {
            var query = @"

SELECT name,AVG(buying) buying,AVG(sales) sales
FROM public.averagetable
group by  name
ORDER BY name ASC 
 ";
            var parameters = new DynamicParameters();
            parameters.Add("@ID", dbType: DbType.Int32, value: 0, direction: ParameterDirection.Input);
            var result = await unitOfWork.GetAll<object>(query, parameters);
            if (result.Any())
            {
                return result;
            }
            return null;
        }
  
    }
}
