﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using WebApi.Services;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScrapingController : ControllerBase
    {
        private readonly IScrapingService _ScrapingService;
        public ScrapingController(IScrapingService ScrapingService)
        {
            _ScrapingService = ScrapingService;
        }

        [HttpGet, Route("GetAll")]
        public async Task<IActionResult> GetAll()
        {
            var result = await _ScrapingService.GetAllAsync();
            return Ok(result);
        }
    }
}
