In ScrapingProject, Change the NpgsqlConnection in ReadData class having OpenConnection() method.
ScrapingProject will create table automatically and collect data 
from (https://www.nadirdoviz.com/fiyatekrani/) and save it in postgres Database.

there are two method that will execute and collect and save data according to the requirements.

**********************

In WebApi Project, Change the ConnectionStrings in appsettings.json file according to the requirement.
WebApi Project will collect data from table and show the result in fronend by using jQuery.
