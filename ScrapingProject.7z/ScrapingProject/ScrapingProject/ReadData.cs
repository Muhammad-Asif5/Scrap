﻿using Dapper;
using HtmlAgilityPack;
using Npgsql;
using System;
using System.Data;
using System.Linq;

namespace ScrapingProject
{
    public class ReadData
    {
        public static void ReadDataFromWebSite()
        {
            DataTable dtHeader = new DataTable();
            var url = "https://www.nadirdoviz.com/fiyatekrani/";
            var web = new HtmlWeb();
            var doc = web.LoadFromWebAsync(url).Result;
            //var table2 = doc.DocumentNode.SelectSingleNode("//table");
            var tableHeader = doc.DocumentNode.SelectNodes("//table/thead/tr[contains(@class, 'trbaslik')]");
            // Extract data from the row
            var headerCells = tableHeader[0].SelectNodes("td"); // 5
            dtHeader = GetHeader(headerCells);
            //var tableRows = doc.DocumentNode.SelectNodes("//table/tbody/tr[@data-symbol='D4']");
            var tableRows = doc.DocumentNode.SelectNodes("//table/tbody/tr[contains(@class ,'trsatir')]");
            for (int i = 0; i < tableRows.Count; i++)
            {
                var check = tableRows[i].SelectNodes("td[contains(@class, 'tdp')]");
                if (check.Count != 1)
                {
                    // Extract data from the row
                    var bodyCells = tableRows[i].SelectNodes("td");
                    TableBody(dtHeader, bodyCells);
                }
                else
                {
                    SaveData(dtHeader);
                    dtHeader = new DataTable();
                    dtHeader = GetHeader(headerCells);
                }
            }
        }
        public static void SaveDataAfter6Hour()
        {
            using (var con = OpenConnection())
            {
                try
                {
                    var query = @"Insert into AverageTable (name,buying,sales)
                                      SELECT name,AVG(buying) buying,AVG(sales) sales
                                      FROM public.maintable
                                      group by  name ";
                    con.Execute(query);
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }
        private static DataTable GetHeader(HtmlNodeCollection cells)
        {
            DataTable dtHeader = new DataTable();
            foreach (var item in cells)
            {
                var cell = item.InnerText;
                if (!String.IsNullOrEmpty(cell))
                {
                    dtHeader.Columns.Add(cell, typeof(string));
                }
            }
            return dtHeader;
        }
        private static void TableBody(DataTable dtHeader, HtmlNodeCollection cells)
        {
            //DataTable dtHeader = new DataTable();
            DataRow dr = dtHeader.NewRow();
            int count = 0;
            for (int i = 0; i < cells.Count; i++)
            {
                var cell = cells[i].InnerText;
                var v = cell.Any(ch => char.IsLetterOrDigit(ch));
                if (!String.IsNullOrEmpty(cell) && v)
                {
                    dr[count] = cell;
                    count++;
                }
            }
            dtHeader.Rows.Add(dr);
        }
        private static void SaveData(DataTable dt)
        {
            using (var con = OpenConnection())
            {
                try
                {
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        var r = dt.Rows[i];
                        double buy = Convert.ToDouble(r.ItemArray[1].ToString().Replace(",", ""));
                        double sel = Convert.ToDouble(r.ItemArray[2].ToString().Replace(",", ""));
                        string query = @"Insert into MainTable (Name,Buying,Sales) values ('" + r.ItemArray[0] + "'," + buy + "," + sel + ")";
                        con.Execute(query);
                    }
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }
        public static void CreateTableIfNotExist()
        {
            using (var con = OpenConnection())
            {
                try
                {
                    string query = @"CREATE TABLE IF NOT EXISTS MainTable(
                                    Id int primary key GENERATED ALWAYS AS IDENTITY, 
                                    Name varchar(100), Buying decimal(10,2),Sales	decimal(10,2))";
                    var res = con.Execute(query);
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }
        public static void CreateSecTableIfNotExist()
        {
            using (var con = OpenConnection())
            {
                try
                {
                    string query = @"CREATE TABLE IF NOT EXISTS AverageTable(
                                    Id int primary key GENERATED ALWAYS AS IDENTITY, 
                                    Name varchar(100), Buying decimal(10,2),Sales	decimal(10,2))";
                    var res = con.Execute(query);
                }
                catch (Exception ex)
                {
                    throw;
                }
            }
        }
        private static IDbConnection OpenConnection()
        {
            var conn = new NpgsqlConnection("Server=localhost;Port=5432;User Id=postgres;Password=123;Database=postgres");
            conn.Open();
            return conn;
        }
    }
}
