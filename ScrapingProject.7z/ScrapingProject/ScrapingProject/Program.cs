﻿using System;
using System.Timers;

namespace ScrapingProject
{
    class Program
    {
        static void Main(string[] args)
        {
            ReadData.CreateTableIfNotExist();
            ReadData.CreateSecTableIfNotExist();
            ReadData.ReadDataFromWebSite();
            ReadData.SaveDataAfter6Hour();

            Timer timer = new Timer(6000 * 60); // 1 Hour interval
            timer.AutoReset = true; // make the timer fire repeatedly
            timer.Elapsed += TimerElapsedAfterOneHour; // handle the Elapsed event of the timer
            timer.Start(); // start the timer

            Timer timer2 = new Timer(6000 * 60 * 6); // 6 Hour interval
            timer2.AutoReset = true;
            timer2.Elapsed += TimerElapsedAfterSixHour;
            timer2.Start();

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        private static void TimerElapsedAfterOneHour(object sender, ElapsedEventArgs e)
        {
            ReadData.ReadDataFromWebSite();
            // Code to run on each timer interval goes here
            Console.WriteLine("Data is Inserted Again in DB at {0}", DateTime.Now);
        }
        private static void TimerElapsedAfterSixHour(object sender, ElapsedEventArgs e)
        {
            ReadData.SaveDataAfter6Hour();
            // Code to run on each timer interval goes here
            Console.WriteLine();
            Console.WriteLine("Data is Inserted Again After 6 Hours in DB at {0}", DateTime.Now);
        }

    }
}
