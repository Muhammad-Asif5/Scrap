﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

using System.Configuration;
using System.Security.Cryptography.X509Certificates;
using System.Net.Http;
using System.Security.Authentication;
using System.Net.Http.Headers;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using Org.BouncyCastle.Crypto.Parameters;
using System.Security.Cryptography;
using System.Web.Configuration;
using LawyerWatch.Library.Utilities;
using System.Web.Script.Serialization;
using LawyerWatch.Library.Utilities;
using System.Web;

namespace LawyerWatch.Library.PushNotfication
{
    public class PushNotificationsTSL
    {
        // Anroid settings
        //string GoogleAppID = ConfigurationSettings.AppSettings.Get("GoogleAppID");
        //string SENDER_ID = ConfigurationSettings.AppSettings.Get("SENDER_ID");

        // IOS Setting
        string IOSBundleId = ConfigurationSettings.AppSettings.Get("IOSBundleId");
        string IOS_Certificate_p8 = ConfigurationSettings.AppSettings.Get("IOS_Certificate_p8");
        string APNSProduction = ConfigurationSettings.AppSettings.Get("APNSProduction");
        string IOSTeamId = ConfigurationSettings.AppSettings.Get("IOSTeamId");
        string IOSKeyId = ConfigurationSettings.AppSettings.Get("IOSKeyId");

        //Please Add these packages from Nuget Packages
        //Microsoft.IdentityModel.Tokens;
        //System.IdentityModel.Tokens.Jwt;
        //portable.bouncycastle //Org.BouncyCastle.Crypto.Parameters;
        //System.Net.Http.WinHttpHandler

        public string SendNotification_IOS(string DeviceToken, string _Message,
                                            Int64 UserID,
                                            Int64 MessageTypeID,
                                            int BatchCount = 0,
                                            string MessageType = "Message",
                                            Int64 GroupID = 0,
                                            Int64 _FromUserID = 0,
                                            string sound = "default")
        {
            try
            {
                string baseUrl = APNSProduction == "1" ? "https://api.push.apple.com:443/3/device/{0}" : "https://api.sandbox.push.apple.com:443/3/device/{0}";
                var url = string.Format(baseUrl, DeviceToken);
                var Token = GetToken();

                JObject _CustomOb = new JObject();
                _CustomOb.Add("MessageType", MessageType);
                _CustomOb.Add("Counter", BatchCount);
                _CustomOb.Add("Message", _Message);
                _CustomOb.Add("UserID", UserID);
                _CustomOb.Add("MessageTypeID", MessageTypeID);
                _CustomOb.Add("FromUserID", _FromUserID);

                var topic = IOSBundleId; // App bundle Id
                using (var httpHandler = new Http2CustomHandler { SslProtocols = SslProtocols.Tls12 })
                {

                    using (var httpClient = new HttpClient(httpHandler, true))
                    {
                        using (var request = new HttpRequestMessage(HttpMethod.Post, url))
                        {
                            request.Headers.Add("apns-id", Guid.NewGuid().ToString("D"));
                            request.Headers.Add("apns-push-type", "alert");
                            request.Headers.Add("apns-priority", "10");
                            request.Headers.Add("apns-topic", topic);
                            request.Headers.Add("authorization", "bearer " + Token);
                            var payload = new Newtonsoft.Json.Linq.JObject{
                                                                {
                                                                    "aps", new Newtonsoft.Json.Linq.JObject
                                                                    {
                                                                        { "alert", _Message},
                                                                        { "sound", sound},
                                                                        { "badge", BatchCount },
                                                                        { "content-available", 1 }
                                                                        ,
                                                                        { "Data", _CustomOb}
                                                                    }
                                                                }
                                                            };
                            request.Content = new StringContent(payload.ToString());
                            try
                            {
                                using (var httpResponseMessage = httpClient.SendAsync(request).GetAwaiter().GetResult())
                                {
                                    var responseContent = httpResponseMessage.Content.ReadAsStringAsync();
                                    if (Convert.ToBoolean(WebConfigurationManager.AppSettings["APILogger"].ToString()) == true)
                                    {
                                        LogHelper.CreateLog(" DeviceToken: " + DeviceToken.ToString() + " " + responseContent.Result.ToString(), ErrorType.Notification);
                                    }
                                }
                            }
                            catch (Exception e)
                            {

                                throw;
                            }
                        }
                    }
                }

                return "success";

            }
            catch (Exception ex)
            {
                return "success";
            }
        }

        public string SendNotification_Android(string DeviceToken, string DeviceMessage,
                                              Int64 UserID, Int64 MessageTypeID,
                                              int BatchCount = 0,
                                              string MessageType = "Message",
                                              Int64 GroupID = 0,
                                              Int64 _FromUserID = 0,
                                              string sound = "default")
        {
            try
            {
                string GoogleAppID = ConfigurationManager.AppSettings["GoogleAppID"];
                string SENDER_ID = ConfigurationManager.AppSettings["SENDER_ID"];

                // var value = message;
                var requestUri = "https://fcm.googleapis.com/fcm/send";

                WebRequest webRequest = WebRequest.Create(requestUri);
                webRequest.Method = "POST";
                webRequest.Headers.Add(string.Format("Authorization: key={0}", GoogleAppID));
                webRequest.Headers.Add(string.Format("Sender: id={0}", SENDER_ID));
                webRequest.ContentType = "application/json";


                var data = new
                {
                    to = DeviceToken, // Uncoment this if you want to test for single device
                    //to = "/topics/" + _topic, // this is for topic 
                    //content_available = true,
                    notification = new
                    {
                        title = WebConfigurationManager.AppSettings["AppName"].ToString(),
                        body = DeviceMessage,
                        //icon="myicon"
                        badge = BatchCount
                    },
                    data = new
                    {
                        title = WebConfigurationManager.AppSettings["AppName"].ToString(),
                        body = DeviceMessage,
                        MessageType = MessageType,
                        UserID = UserID,
                        MessageTypeID = MessageTypeID,
                        FromUserID = _FromUserID
                    }
                };


                var serializer = new JavaScriptSerializer();
                var json = serializer.Serialize(data);

                Byte[] byteArray = Encoding.UTF8.GetBytes(json);

                webRequest.ContentLength = byteArray.Length;
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                using (Stream dataStream = webRequest.GetRequestStream())
                {
                    dataStream.Write(byteArray, 0, byteArray.Length);

                    using (WebResponse webResponse = webRequest.GetResponse())
                    {
                        using (Stream dataStreamResponse = webResponse.GetResponseStream())
                        {
                            using (StreamReader tReader = new StreamReader(dataStreamResponse))
                            {
                                String sResponseFromServer = tReader.ReadToEnd();
                                //result.Response = sResponseFromServer;
                            }
                        }
                    }
                }


                return "success";
            }
            catch (Exception ex)
            {
                return ex.ToString();
            }
        }

        public class Http2CustomHandler : WinHttpHandler
        {
            protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, System.Threading.CancellationToken cancellationToken)
            {
                request.Version = new Version("2.0");
                return base.SendAsync(request, cancellationToken);
            }
        }

        #region GetToken

        public string GetToken()
        {
            var dsa = GetECDsa();
            return CreateJwt(dsa, IOSKeyId, IOSTeamId);
        }
        ECDsa GetECDsa()
        {
            using (TextReader reader = System.IO.File.OpenText(IOS_Certificate_p8))
            {
                var ecPrivateKeyParameters =
                (ECPrivateKeyParameters)new Org.BouncyCastle.OpenSsl.PemReader(reader).ReadObject();

                var q = ecPrivateKeyParameters.Parameters.G.Multiply(ecPrivateKeyParameters.D).Normalize();
                var qx = q.AffineXCoord.GetEncoded();
                var qy = q.AffineYCoord.GetEncoded();
                var d = ecPrivateKeyParameters.D.ToByteArrayUnsigned();

                // Convert the BouncyCastle key to a Native Key.
                var msEcp = new ECParameters { Curve = ECCurve.NamedCurves.nistP256, Q = { X = qx, Y = qy }, D = d };
                return ECDsa.Create(msEcp);
            }
        }
        string CreateJwt(ECDsa key, string keyId, string teamId)
        {
            var securityKey = new ECDsaSecurityKey(key) { KeyId = keyId };
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.EcdsaSha256);

            var descriptor = new SecurityTokenDescriptor
            {
                IssuedAt = DateTime.Now,
                Issuer = teamId,
                SigningCredentials = credentials,

            };

            var handler = new JwtSecurityTokenHandler();
            var encodedToken = handler.CreateEncodedJwt(descriptor);
            return encodedToken;
        }

        #endregion

        #region DotNet Core Send Push notication using Certificate file .p12

        //public string SendNotification(YourClass input)
        //{

        //    try
        //    {
        //        JObject _CustomOb = new JObject();
        //        _CustomOb.Add("Type", "gfh");
        //        _CustomOb.Add("UserReservationId", 1);

        //        string p12File = string.Empty;
        //        p12File = input.fileUrl;
        //        var url = string.Format("https://api.sandbox.push.apple.com:443/3/device/{0}", input.deviceToken);
        //        //var certData = System.IO.File.ReadAllBytes(@"E:\Projects\APNS_ML\APNS_ML\APNS_ML\Certificates.p12");
        //        var certData = System.IO.File.ReadAllBytes(@"F:\www\PushNotification\Certificates.p12");
        //        var certificate = new X509Certificate2(certData, "", X509KeyStorageFlags.MachineKeySet | X509KeyStorageFlags.PersistKeySet | X509KeyStorageFlags.Exportable);
        //        var topic = input.bundleId; // App bundle Id
        //        using (var httpHandler = new HttpClientHandler { SslProtocols = SslProtocols.Tls12 })
        //        {
        //            httpHandler.ClientCertificates.Add(certificate);
        //            using (var httpClient = new HttpClient(httpHandler, true))
        //            {
        //                using (var request = new HttpRequestMessage(HttpMethod.Post, url))
        //                {
        //                    request.Headers.Add("apns-id", Guid.NewGuid().ToString("D"));
        //                    request.Headers.Add("apns-push-type", "alert");
        //                    request.Headers.Add("apns-priority", "10");
        //                    request.Headers.Add("apns-topic", topic);

        //                    var payload = new Newtonsoft.Json.Linq.JObject{
        //                {
        //                    "aps", new Newtonsoft.Json.Linq.JObject
        //                    {
        //                        { "alert", input.message },
        //                        { "sound", (string.IsNullOrEmpty(input.sound) ? "default" : input.sound)},
        //                        { "badge", input.badgeCount },
        //                        { "content-available", 1 }
        //                        ,
        //                        { "Data", _CustomOb}

        //                    }
        //                }
        //            };
        //                    request.Content = new StringContent(payload.ToString());
        //                    request.Version = new Version(2, 0);
        //                    try
        //                    {
        //                        using (var httpResponseMessage = httpClient.SendAsync(request).GetAwaiter().GetResult())
        //                        {
        //                            var responseContent = httpResponseMessage.Content.ReadAsStringAsync();
        //                        }
        //                    }
        //                    catch (Exception e)
        //                    {

        //                        throw;
        //                    }
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //    }

        //}

        #endregion
    }
}
