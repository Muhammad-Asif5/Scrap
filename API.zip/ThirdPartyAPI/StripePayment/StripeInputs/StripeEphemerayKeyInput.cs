﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Stripe;

namespace LawyerWatch.Paymentlib.StripeInputs
{
    public class StripeEphemerayKeyInput 
    {
        public string Id { get; set; }
        public string Object { get; set; }
        public List<object> AssociatedObjects { get; set; }
        public DateTime Created { get; set; }
        //
        // Summary:
        //     Whether this object is deleted or not.
        public bool? Deleted { get; set; }
        public DateTime Expires { get; set; }
        public bool Livemode { get; set; }
        //
        // Summary:
        //     Stripe.EphemeralKey.RawJson is the raw JSON data of the response that was used
        //     to initialize this ephemeral key. When working with mobile clients that might
        //     only understand one version of the API you should prefer to send this value back
        //     to them so that they'll be able to decode an object that's current according
        //     to their version.
        public string RawJson { get; }
        public string secret { get; set; }
    }
}