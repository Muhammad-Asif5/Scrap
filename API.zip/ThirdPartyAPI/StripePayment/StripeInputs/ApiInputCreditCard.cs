﻿using System;
using System.Collections.Generic;

using System.Linq;
using System.Web;

namespace LawyerWatch.Paymentlib.StripeInputs
{
    public class ApiInputCreditCard
    {
        //[Required]
        public long UserId { get; set; }
        
        //[Required]
        public string StripeToken { get; set; }
    }
}