﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LawyerWatch.Paymentlib.StripeInputs
{
    public class ApiCreditCardView
    {
        public string CardholderName { get; set; }
        public string CustomerId { get; set; }
        public Nullable<bool> IsDefault { get; set; }
        public string CardId { get; set; }
        public string ImageUrl { get; set; }
        public string ExpirationDate { get; set; }
        public string MaskedNumber { get; set; }
    }
}