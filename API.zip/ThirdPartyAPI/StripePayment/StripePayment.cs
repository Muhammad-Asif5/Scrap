﻿using LawyerWatch.Library.API;
using LawyerWatch.Library.Utilities;
using LawyerWatch.Paymentlib.StripeInputs;
using LawyerWatch.Paymentlib;
using Stripe;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using LawyerWatch.Library;
using Newtonsoft.Json;
using System.Web.Configuration;
//using System.Web.Script.Serialization;

namespace LawyerWatch.StripePayment.Paymentlib
{

    public class PaymentResponse
    {
        public string PaymentKey { get; set; }

        public string URL { get; set; }

        public string ErrorDescription { get; set; }

        public string PaymentStatus { get; set; }
        public bool IsSuccess { get; set; } = true;

        public List<ApiCreditCardView> CreditCards { get; set; } = new List<ApiCreditCardView>();
        public string CustomerId { get; set; }
    }
    public class VerificationSessionMoodel
    {
        public string Id { get; set; }
        public string Status { get; set; }
        public string Type { get; set; }
        public string Url { get; set; }
        public bool IsSuccess { get; set; } = true;
        public string ErrorDescription { get; set; }
    }

    public enum PayoutStatus
    {
        paid,
        pending,
        in_transit,
        canceled,
        failed
    }

    public class StripePayment
    {

        public StripePayment()
        {
            StripeConfiguration.ApiKey = WebConfigurationManager.AppSettings["StripeSecretkey"].ToString();

        }
        static StripePayment()
        {
            StripeConfiguration.ApiKey = WebConfigurationManager.AppSettings["StripeSecretkey"].ToString();

        }


       


        public PaymentResponse AddCreditCard(string CustomerId, string StripeToken)
        {
            PaymentResponse response = new PaymentResponse();
            try
            {
                var cardService = new CardService();
                var cardCreateOptions = new CardCreateOptions
                {
                    Source = StripeToken
                };
                var result = cardService.Create(CustomerId, cardCreateOptions);
                response.IsSuccess = true;
                return GetCreditCards(CustomerId);
            }
            catch (StripeException e)
            {
                LogHelper.CreateLog(e.StripeError.Message);
                response.IsSuccess = false;
                response.ErrorDescription = e.StripeError.Message;
                return response;
            }
        }
        public PaymentResponse DeleteCreditCards(string CardId, string BraintreeCustomerID)
        {
            PaymentResponse response = new PaymentResponse();
            try
            {
                var cardService = new CardService();
                var result = cardService.Delete(BraintreeCustomerID, CardId);
                response.IsSuccess = true;
                return GetCreditCards(BraintreeCustomerID);


            }
            catch (StripeException e)
            {
                LogHelper.CreateLog(e.StripeError.Message);
                response.IsSuccess = false;
                response.ErrorDescription = e.StripeError.Message;
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex);
                response.IsSuccess = false;
                response.ErrorDescription = ex.Message;
                return response;
            }
        }
        public PaymentResponse MakeDefaultCreditCards(string CardId, string BraintreeCustomerID)
        {
            PaymentResponse response = new PaymentResponse();
            try
            {
                var customerService = new CustomerService();
                Customer customer = customerService.Get(BraintreeCustomerID);
                if (customer != null)
                {
                    if (customer.DefaultSourceId != CardId)
                    {
                        var cardService = new CardService();
                        var result = cardService.Get(BraintreeCustomerID, CardId);
                        if (result != null)
                        {
                            var cusUpdateOptions = new CustomerUpdateOptions
                            {
                                DefaultSource = CardId
                            };

                            customerService.Update(BraintreeCustomerID, cusUpdateOptions);
                        }
                    }
                }
                response.IsSuccess = true;
                return GetCreditCards(BraintreeCustomerID);
            }
            catch (StripeException e)
            {

                response.IsSuccess = false;
                response.ErrorDescription = e.StripeError.Message;
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex);
                response.IsSuccess = false;
                response.ErrorDescription = ex.Message;
                return response;
            }
        }
        public PaymentResponse GetCreditCards(string BraintreeCustomerID)
        {
            PaymentResponse response = new PaymentResponse();
            try
            {
                var customerService = new CustomerService();
                var result = customerService.Get(BraintreeCustomerID);
                var Data = result.Sources.Data;
                if (Data == null && Data.Count == 0)
                {
                    return response;
                }
                foreach (Card item in Data)
                {
                    bool isDefault = false;
                    if (result.DefaultSourceId == item.Id)
                    {
                        isDefault = true;
                    }
                    ApiCreditCardView obj = new ApiCreditCardView()
                    {
                        CardholderName = item.Name ?? "",
                        CustomerId = BraintreeCustomerID,
                        ExpirationDate = item.ExpMonth.ToString() + "/" + item.ExpYear.ToString(),
                        ImageUrl = GetCardImageIcon(item.Brand),
                        IsDefault = isDefault,
                        MaskedNumber = "**********" + item.Last4,
                        CardId = item.Id
                    };

                    response.CreditCards.Add(obj);

                }
                response.IsSuccess = true;
                return response;
            }
            catch (StripeException e)
            {
                LogHelper.CreateLog(e.StripeError.Message);
                response.IsSuccess = false;
                response.ErrorDescription = e.StripeError.Message;
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex);
                response.IsSuccess = false;
                response.ErrorDescription = ex.Message;
                return response;
            }
        }

        public PaymentResponse GetCreditCards2(string BraintreeCustomerID)
        {
            PaymentResponse response = new PaymentResponse();
            try
            {
                var service = new CardService();
                var options = new CardListOptions
                {
                    Limit = 3,
                };
                var cards = service.List(BraintreeCustomerID, options);
                response.IsSuccess = true;
                return response;
            }
            catch (StripeException e)
            {
                LogHelper.CreateLog(e.StripeError.Message);
                response.IsSuccess = false;
                response.ErrorDescription = e.StripeError.Message;
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex);
                response.IsSuccess = false;
                response.ErrorDescription = ex.Message;
                return response;
            }
        }

        public string GetCardImageIcon(string CardType)
        {
            string basePath = ConfigurationManager.AppSettings["WebPath"] + "Content/images/";
            string cardIconPath = "";

            if (CardType.Contains("Visa"))
            {
                cardIconPath = basePath + "visa.png";
            }
            else if (CardType.Contains("MasterCard"))
            {
                cardIconPath = basePath + "MasterCard.png";
            }
            else if (CardType.Contains("American Express"))
            {
                cardIconPath = basePath + "americanexpress.png";
            }
            else if (CardType.Contains("Discover"))
            {
                cardIconPath = basePath + "discover.png";
            }
            else if (CardType.Contains("Diners Club"))
            {
                cardIconPath = basePath + "diners.png";
            }
            else if (CardType.Contains("JCB"))
            {
                cardIconPath = basePath + "jsb.png";
            }
            else if (CardType.Contains("UnionPay"))
            {
                cardIconPath = basePath + "unionpay.png";
            }

            return cardIconPath;
        }

        public PaymentResponse MakePayment(decimal amount, string Nounce, string PaymentType, string _EventNote, bool _Authorize = true, string _Currency = "usd")
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {

                if (_Currency == "US Dollar" || _Currency == "Euro"
                    || _Currency == "Sterling"
                    )
                {
                    _Currency = "usd";
                }

                Charge charge = new Charge();

                Int64 _amount = Numerics.GetInt(amount * 100);

                if (PaymentType == "Card")
                {
                    if (!String.IsNullOrEmpty(Nounce))
                    {
                        // This transaction is made using Nonce
                        var options = new ChargeCreateOptions
                        {
                            Amount = _amount,
                            //Currency = "usd",
                            Currency = _Currency,
                            Description = _EventNote,
                            Source = Nounce, //"tok_visa"
                            Capture = _Authorize
                        };
                        var service = new ChargeService();
                        charge = service.Create(options);
                    }
                }
                _PaymentResponse.PaymentKey = charge.Id;
                _PaymentResponse.PaymentStatus = charge.Status;

                //_PaymentResponse.ErrorDescription = charge.des;
                _PaymentResponse.IsSuccess = true;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {

                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
        }

        #region "Payment method"
        public PaymentResponse MakePayment(string StripeCustomerID, string PaymentMethodId, decimal amount, string _CaptureMethod = "automatic")
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {
                //PaymentMethodId = "pm_1LpBsPExKsD6WdSME3dn4MYv";
                //StripeCustomerID = "cus_MVHw5lSIni1WmS";
                //amount = 2000;
                var service = new PaymentIntentService();
                Int64 _amount = Numerics.GetInt(amount * 100);
                var options = new PaymentIntentCreateOptions
                {
                    PaymentMethodTypes = new List<string> { "card" },
                    Amount = _amount,
                    Currency = "usd",
                    Customer = StripeCustomerID,
                    PaymentMethod = PaymentMethodId,
                    OffSession = true,
                    Confirm = true,
                    Description = "Stripe Payment",
                    CaptureMethod = _CaptureMethod
                };



                PaymentIntent response = service.Create(options);

                _PaymentResponse.PaymentKey = response.Id;
                _PaymentResponse.PaymentStatus = response.Status;
                _PaymentResponse.IsSuccess = true;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {



                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
        }

        public PaymentResponse AttachPaymentMethod(string PaymentMethodId, string CustomerId)
        {
            PaymentResponse response = new PaymentResponse();
            try
            {
                //var cardService = new CardService();
                //var result = cardService.Delete(BraintreeCustomerID, CardId);
                var options = new PaymentMethodAttachOptions
                {
                    Customer = CustomerId,
                };



                var service = new PaymentMethodService();
                service.Attach(
                  PaymentMethodId,
                  options);



                response.IsSuccess = true;
                return GetCreditCards(PaymentMethodId);




            }
            catch (StripeException e)
            {
                LogHelper.CreateLog(e.StripeError.Message);
                response.IsSuccess = false;
                response.ErrorDescription = e.StripeError.Message;
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex);
                response.IsSuccess = false;
                response.ErrorDescription = ex.Message;
                return response;
            }
        }

        #endregion

        public PaymentResponse MakePaymentByCustomerID(decimal amount, string StripeCustomerID, string PaymentType, string _EventNote, bool _Authorize = true, string _Currency = "usd")
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {

                if (_Currency == "US Dollar" || _Currency == "Euro"
                    || _Currency == "Sterling"
                    )
                {
                    _Currency = "usd";
                }

                Charge charge = new Charge();

                Int64 _amount = Numerics.GetInt(amount * 100);

                if (PaymentType == "Card")
                {
                    if (!String.IsNullOrEmpty(StripeCustomerID))
                    {
                        // This transaction is made using Nonce
                        var options = new ChargeCreateOptions
                        {
                            Amount = _amount,
                            //Currency = "usd",
                            Currency = _Currency,
                            Description = _EventNote,
                            Customer = StripeCustomerID,
                            Capture = _Authorize
                        };
                        var service = new ChargeService();
                        charge = service.Create(options);
                    }
                }
                _PaymentResponse.PaymentKey = charge.Id;
                _PaymentResponse.PaymentStatus = charge.Status;

                //_PaymentResponse.ErrorDescription = charge.des;
                _PaymentResponse.IsSuccess = true;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {

                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
        }


        //to settle the authorize amount in full
        public PaymentResponse ChargeCaptureforSettlement(string _StripeTransactionId)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {

                var _option = new PaymentIntentCaptureOptions();

                var service = new PaymentIntentService();
                var charge = service.Capture(_StripeTransactionId, _option);

                _PaymentResponse.PaymentKey = charge.Id;
                _PaymentResponse.PaymentStatus = charge.Status;

                //_PaymentResponse.ErrorDescription = charge.des;
                _PaymentResponse.IsSuccess = true;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {

                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
        }

        //to settle the authorize amount in partial and refund the remaining
        public PaymentResponse ChargeCaptureforSettlementPartial(string _StripeTransactionId, decimal amount)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {

                Int64 _amount = Numerics.GetInt(amount * 100);

                var _option = new PaymentIntentCaptureOptions
                {
                    AmountToCapture = _amount
                };

                var service = new PaymentIntentService();
                var charge = service.Capture(_StripeTransactionId, _option);

                //You can only perform one capture on an authorized payment. If you partially capture a payment, you can’t perform another capture for the difference. (Instead, consider saving the customer’s card details for later and creating future payments as needed.)

                _PaymentResponse.PaymentKey = charge.Id;
                _PaymentResponse.PaymentStatus = charge.Status;

                //_PaymentResponse.ErrorDescription = charge.des;
                _PaymentResponse.IsSuccess = true;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {

                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
        }

        //refund the amount which is already been settled partially
        public PaymentResponse RefundStripePayment(string BraintreeTransactionID, decimal amount)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();

            try
            {

                Int64 _amount = Numerics.GetInt(amount * 100);
                var options = new RefundCreateOptions
                {
                    PaymentIntent = BraintreeTransactionID,
                    Amount = _amount
                };

                var service = new RefundService();
                var _refund = service.Create(options);

                _PaymentResponse.PaymentKey = _refund.Id;
                _PaymentResponse.PaymentStatus = _refund.Status;
                _PaymentResponse.IsSuccess = true;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.ErrorDescription = ex.Message;
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
        }

        //refund tha amount which is already been settled full
        public PaymentResponse RefundStripePaymentFull(string BraintreeTransactionID)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();

            try
            {

                var options = new RefundCreateOptions
                {
                    PaymentIntent = BraintreeTransactionID
                };

                var service = new RefundService();
                var _refund = service.Create(options);

                _PaymentResponse.PaymentKey = _refund.Id;
                _PaymentResponse.PaymentStatus = _refund.Status;
                _PaymentResponse.IsSuccess = true;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.ErrorDescription = ex.Message;
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
        }

        //refund/cacel the amount which are not beeing settled yet 
        public PaymentResponse CancelStripeAuthorizedPayment(string BraintreeTransactionID)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();

            try
            {

                var options = new PaymentIntentCancelOptions();

                var service = new PaymentIntentService();
                var _refund = service.Cancel(BraintreeTransactionID, options);

                _PaymentResponse.PaymentKey = _refund.Id;
                _PaymentResponse.PaymentStatus = _refund.Status;
                _PaymentResponse.IsSuccess = true;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.ErrorDescription = ex.Message;
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
        }



        //create the customer in stripe 
        public PaymentResponse CreateUser(string Email)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {
                string CustomerId = "";
                CustomerCreateOptions customerOptions;
                customerOptions = new CustomerCreateOptions
                {
                    Email = Email
                };
                var customerService = new CustomerService();
                Customer customer = customerService.Create(customerOptions);
                _PaymentResponse.CustomerId = customer.Id;
                _PaymentResponse.IsSuccess = true;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.ErrorDescription = ex.Message;
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
        }

        public PaymentResponse CreateUser(string FullName, string PhoneNumber)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {
                string CustomerId = "";
                CustomerCreateOptions customerOptions;
                customerOptions = new CustomerCreateOptions
                {
                    Name = FullName,
                    Phone = PhoneNumber
                };
                var customerService = new CustomerService();
                Customer customer = customerService.Create(customerOptions);
                _PaymentResponse.CustomerId = customer.Id;
                _PaymentResponse.IsSuccess = true;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.ErrorDescription = ex.Message;
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
        }

        public object GetEphemeralKey(string StripeCustomerID, string StripeVersion)
        {

            try
            {
                Stripe.EphemeralKeyCreateOptions _epheOptions = new EphemeralKeyCreateOptions
                {
                    Customer = StripeCustomerID,
                    StripeVersion = StripeVersion
                };

                Stripe.EphemeralKey response = new Stripe.EphemeralKeyService().Create(_epheOptions);
                object ParseResponse = JsonConvert.DeserializeObject<EphemeralResponse>(response.RawJson);
                return ParseResponse;
                //return null;
                //return new StripeEphemerayKeyInput
                //{
                //    Id = response.Id,
                //    Object = response.Object,
                //    //AssociatedObjects = response.AssociatedObjects,
                //    Created = response.Created,
                //    Expires = response.Expires,
                //    Livemode = response.Livemode,
                //    secret = ConfigurationManager.AppSettings["StripeConfigurationApiKey"]
                //};

            }
            catch (StripeException e)
            {
                LogHelper.CreateLog(e.StripeError.Message);
                //return new StripeEphemerayKeyInput() ;
                return JsonResponse.GetResponse(ResponseCode.Failure, e.StripeError.Message);
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex);
                return JsonResponse.GetResponse(ResponseCode.Exception, ex.Message);
                //return new StripeEphemerayKeyInput();
            }
        }

        public object GetPaymentIntentSecretKey(decimal Amount, string CustomerID, string _Description, string _CaptureMethod = "automatic")
        {

            try
            {

                var service = new PaymentIntentService();
                var options = new PaymentIntentCreateOptions
                {
                    Amount = Numerics.GetInt(Amount * 100),
                    Currency = "usd",
                    PaymentMethodTypes = new List<string>
                      {
                        "card",
                      },
                    Customer = CustomerID,
                    //PaymentMethod= "pm_1Jcu6dDCg8y7hR8XHryu3lPL",
                    //OffSession =true,
                    //Confirm=true,
                    SetupFutureUsage = "off_session", //"off_session"/"on_session"
                    Description = _Description

                };
                object response = service.Create(options);
                return response;

            }
            catch (StripeException e)
            {
                LogHelper.CreateLog(e.StripeError.Message);
                //return new StripeEphemerayKeyInput() ;
                return e.StripeError.Message;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex);
                return JsonResponse.GetResponse(ResponseCode.Exception, ex.Message);
                //return new StripeEphemerayKeyInput();
            }
        }

        //to get the payment intent against the customer
        public object GetPaymentIntentSecretKey(decimal Amount, string CustomerID, string _CaptureMethod = "automatic")
        {

            try
            {
                var EAmount = Convert.ToInt64(Amount * 100);
                var service = new PaymentIntentService();

                //var _payment = new PaymentMethod
                //{

                //};

                var options = new PaymentIntentCreateOptions
                {
                    Amount = EAmount,
                    Currency = "usd",
                    CaptureMethod = _CaptureMethod,//"manual"/ "automatic",
                    PaymentMethodTypes = new List<string>
                      {
                        "card",
                      },
                    Customer = CustomerID,
                    //PaymentMethod= "pm_1Jcu6dDCg8y7hR8XHryu3lPL",
                    //OffSession =true,
                    //Confirm=true,
                    SetupFutureUsage = "off_session", //"off_session"/"on_session"

                };
                object response = service.Create(options);
                return response;

            }
            catch (StripeException e)
            {
                LogHelper.CreateLog(e.StripeError.Message);
                //return new StripeEphemerayKeyInput() ;
                throw new ArgumentException(e.StripeError.Message);

            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex);
                throw new ArgumentException(ex.Message);

                //return new StripeEphemerayKeyInput();
            }
        }


        //to auto charge/authorize the customer against his save card in future
        public PaymentResponse GetPaymentMethodofCustomer(string CustomerID)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {

                var options = new PaymentMethodListOptions
                {
                    Customer = CustomerID,
                    Type = "card",
                };
                var service = new PaymentMethodService();
                StripeList<PaymentMethod> paymentMethods = service.List(
                  options
                );
                _PaymentResponse.PaymentKey = paymentMethods.Data[0].Id;
                _PaymentResponse.IsSuccess = true;
                return _PaymentResponse;
            }
            catch (StripeException e)
            {
                LogHelper.CreateLog(e.StripeError.Message);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = e.Message;
                //return new StripeEphemerayKeyInput() ;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
                //return new StripeEphemerayKeyInput();
            }
        }

        //to auto charge/authorize the customer against his save card in future
        public PaymentResponse PaymentIntentToChargeofsession(decimal Amount, string CustomerID, string _PaymentMethod, string _Description, string _CaptureMethod = "automatic")
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {
                var EAmount = Convert.ToInt64(Amount * 100);
                var service = new PaymentIntentService();

                //var _payment = new PaymentMethod
                //{

                //};

                var options = new PaymentIntentCreateOptions
                {
                    Amount = EAmount,
                    Currency = "usd",
                    CaptureMethod = _CaptureMethod,//"manual"/ "automatic",
                    PaymentMethodTypes = new List<string>
                      {
                        "card",
                      },
                    Customer = CustomerID,
                    PaymentMethod = _PaymentMethod,
                    OffSession = true,
                    Confirm = true,
                    Description = _Description
                };
                PaymentIntent response = service.Create(options);

                _PaymentResponse.PaymentKey = response.Id;
                _PaymentResponse.IsSuccess = true;

                return _PaymentResponse;

            }
            catch (StripeException e)
            {
                LogHelper.CreateLog(e.StripeError.Message);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = e.Message;
                //return new StripeEphemerayKeyInput() ;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
                //return new StripeEphemerayKeyInput();
            }
        }

        #region "Market Place"

        //public ApiResponse CreateConnectedAccountStripeACH(int UserId, string RoutingNumber, string AccountNumber, string Email, string FirstName, string LastName, string WebSite, string DBAName, string LegalName, string myIP, string userAgent)
        //{
        //    try
        //    {
        //        StripeConfiguration.ApiKey = ConfigurationManager.AppSettings["StripeConfigurationApiKey"];

        //        _userGenericRepository = new GenericRepository<User>(_unitOfWork);
        //        _userBankAccount = new GenericRepository<UserBankAccount>(_unitOfWork);

        //        var userBankAccount = _userBankAccount.Repository.Get(x => x.UserId == UserId);

        //        var entityuser = _userGenericRepository.Repository.Get(x => x.UserId == UserId);
        //        if (entityuser == null)
        //        {
        //            return JsonResponse.GetResponse(Enums.ResponseCode.Failure, "User not found.");
        //        }

        //        #region ACH

        //        ACHResponse achRes = null;
        //        string NIACSCode = "";
        //        string NIACSDescription = "";
        //        if (entityuser.UserApp.ToLower() == Enums.UserApp.Vendor.ToString().ToLower())
        //        {
        //            _vendorServiceCategory = new GenericRepository<VendorServiceCategory>(_unitOfWork);
        //            _serviceCategory = new GenericRepository<ServiceCategory>(_unitOfWork);
        //            var vendorCategory = _vendorServiceCategory.Repository.FirstOrDefault(x => x.VendorId == UserId);
        //            var serviceCategory = _serviceCategory.Repository.Get(x => x.ServiceCategoryId == vendorCategory.ServiceCategoryId);
        //            NIACSCode = serviceCategory.NIACSCode;
        //            NIACSDescription = serviceCategory.CategoryName;
        //        }
        //        HTTP.BankAccountResponse bankResponse = new HTTP.BankAccountResponse
        //        {
        //            merchantID = ConfigurationManager.AppSettings["MerchantID"].ToString(),
        //            login = ConfigurationManager.AppSettings["Login"].ToString(),
        //            password = ConfigurationManager.AppSettings["Password"].ToString(),
        //            emailAddress = Email,
        //            legalName = LegalName,
        //            dbaName = DBAName,
        //            bankAccountNo = AccountNumber,
        //            bankRouteNo = RoutingNumber,
        //            disableWelcomeEmail = true,
        //            naics = NIACSCode,
        //            businessDesc = NIACSDescription,
        //            webhook_url = ConfigurationManager.AppSettings["ACHReturnURL"].ToString()

        //        };


        //        try
        //        {
        //            var reponse = HTTP.HttpHelper.PostSimple(ConfigurationManager.AppSettings["ACHEnrollAccountURL"] + "enroll.svc/JSON/CreateMerchant", bankResponse);

        //            achRes = JsonConvert.DeserializeObject<ACHResponse>(reponse);
        //            if (achRes.status == "success")
        //            {
        //                if (entityuser.UserApp.ToLower() == Enums.UserApp.Vendor.ToString().ToLower())
        //                {
        //                    if (userBankAccount != null)
        //                    {
        //                        userBankAccount.ACHAccountId = achRes.guid;
        //                        userBankAccount.ACHAccountStatus = "Pending";
        //                        userBankAccount.ModifiedDate = DateTime.UtcNow;
        //                        userBankAccount.MaskedAccountNumber = "********" + AccountNumber.Substring(AccountNumber.Length - 4, 4);
        //                        _userBankAccount.Repository.Update(userBankAccount);
        //                    }
        //                    else
        //                    {
        //                        userBankAccount = new UserBankAccount();
        //                        userBankAccount.ACHAccountId = achRes.guid;
        //                        userBankAccount.ACHAccountStatus = "Pending";
        //                        userBankAccount.ModifiedDate = DateTime.UtcNow;
        //                        userBankAccount.CreatedDate = DateTime.UtcNow;
        //                        userBankAccount.MaskedAccountNumber = "********" + AccountNumber.Substring(AccountNumber.Length - 4, 4);
        //                        userBankAccount.UserId = UserId;
        //                        _userBankAccount.Repository.Add(userBankAccount);
        //                    }
        //                }
        //                else if (entityuser.UserApp.ToLower() == Enums.UserApp.Main.ToString().ToLower())
        //                {
        //                    userBankAccount = new UserBankAccount();
        //                    userBankAccount.ACHAccountId = achRes.guid;
        //                    userBankAccount.ACHAccountStatus = "Pending";
        //                    userBankAccount.ModifiedDate = DateTime.UtcNow;
        //                    userBankAccount.CreatedDate = DateTime.UtcNow;
        //                    userBankAccount.MaskedAccountNumber = "********" + AccountNumber.Substring(AccountNumber.Length - 4, 4);
        //                    userBankAccount.UserId = UserId;
        //                    _userBankAccount.Repository.Add(userBankAccount);
        //                }
        //            }
        //            else
        //            {
        //                string errorDescription = "";
        //                if (achRes.validationErrors.Count > 0)
        //                {
        //                    var validationsErrors = JObject.Parse(achRes.validationErrors[0].ToString());
        //                    errorDescription = validationsErrors["errorDescription"].ToString();
        //                }
        //                else
        //                {
        //                    errorDescription = achRes.message;
        //                }
        //                LogHelper.CreateLog(errorDescription + ":: ACH");
        //                return JsonResponse.GetResponse(Enums.ResponseCode.Failure, errorDescription);
        //            }
        //        }
        //        catch (Exception ex)
        //        {
        //            LogHelper.CreateLog(ex);
        //            return JsonResponse.GetResponse(Enums.ResponseCode.Failure, ex.Message);
        //        }
        //        #endregion

        //        #region Stripe Connented Account
        //        if (entityuser.UserApp.ToLower() == Enums.UserApp.Vendor.ToString().ToLower())
        //        {
        //            ////////////////TAnd Conditions
        //            var TaC = new AccountTosAcceptanceOptions
        //            {
        //                Date = DateTime.Now,
        //                Ip = myIP,
        //                UserAgent = userAgent
        //            };
        //            var individual = new PersonCreateOptions
        //            {
        //                FirstName = FirstName,
        //                LastName = LastName,
        //                Email = Email,
        //            };

        //            if (ConfigurationManager.AppSettings["ACHMode"].ToString() != "Live")
        //            {
        //                AccountNumber = "000123456789";
        //                RoutingNumber = "110000000";
        //            }

        //            var externalAccount = new AccountBankAccountOptions
        //            {
        //                Country = "US",
        //                Currency = "USD",
        //                AccountNumber = AccountNumber,
        //                RoutingNumber = RoutingNumber
        //            };
        //            var bussinessProfile = new AccountBusinessProfileOptions
        //            {
        //                Url = WebSite
        //            };

        //            List<string> li = new List<string>();
        //            //li.Add("card_payments");
        //            //li.Add("platform_payments");
        //            li.Add("transfers");
        //            var options = new AccountCreateOptions
        //            {
        //                Email = Email,
        //                Type = AccountType.Custom,
        //                Country = "US",
        //                DefaultCurrency = "USD",
        //                BusinessType = "individual",
        //                Individual = individual,
        //                ExternalAccount = externalAccount,
        //                RequestedCapabilities = li,
        //                TosAcceptance = TaC,
        //                BusinessProfile = bussinessProfile
        //            };

        //            var service = new AccountService();
        //            Account account = service.Create(options);

        //            if (entityuser.UserApp.ToLower() == Enums.UserApp.Vendor.ToString().ToLower())
        //            {
        //                if (userBankAccount != null)
        //                {
        //                    userBankAccount.StripeAccountId = account.Id;
        //                    userBankAccount.StripeAccountStatus = "Approved";
        //                    userBankAccount.ModifiedDate = DateTime.UtcNow;
        //                    userBankAccount.MaskedAccountNumber = "********" + AccountNumber.Substring(AccountNumber.Length - 4, 4);
        //                    _userBankAccount.Repository.Update(userBankAccount);
        //                }
        //            }
        //            else if (entityuser.UserApp.ToLower() == Enums.UserApp.Main.ToString().ToLower())
        //            {
        //                userBankAccount.StripeAccountId = account.Id;
        //                userBankAccount.StripeAccountStatus = "Approved";
        //                userBankAccount.ModifiedDate = DateTime.UtcNow;
        //                userBankAccount.MaskedAccountNumber = "********" + AccountNumber.Substring(AccountNumber.Length - 4, 4);
        //                _userBankAccount.Repository.Update(userBankAccount);
        //            }
        //        }
        //        #endregion


        //        Dictionary<string, object> response = new Dictionary<string, object>();
        //        response.Add("ACHAccountUrl", ConfigurationManager.AppSettings["ACHEnrollWebViewURL"] + "click_to_agree.aspx?id=" + achRes.guid);

        //        return JsonResponse.GetResponse(Enums.ResponseCode.Success, response);
        //    }
        //    catch (StripeException e)
        //    {
        //        LogHelper.CreateLog(e.StripeError.Message + ":: Stripe");
        //        return JsonResponse.GetResponse(Enums.ResponseCode.Failure, e.StripeError.Message);
        //    }
        //    catch (Exception ex)
        //    {
        //        LogHelper.CreateLog(ex);
        //        return JsonResponse.GetResponse(Enums.ResponseCode.Failure, ex.Message);
        //    }
        //}

        public object GetConnectPaymentIntentSecretKey(decimal _Amount, string _CustomerID, string _StripeAccountId, string _Description)
        {

            try
            {


                var service = new PaymentIntentService();

                decimal _ApplicationFee = _Amount * Convert.ToDecimal(ConfigurationManager.AppSettings["APP_Share"]);
                decimal _amountFeeDeduct = _Amount - (_Amount * Convert.ToDecimal(ConfigurationManager.AppSettings["APP_Share"]));


                var _PaymentIntentTransferDataOptions = new PaymentIntentTransferDataOptions()
                {
                    Destination = _StripeAccountId,
                    Amount = Numerics.GetInt(_amountFeeDeduct * 100)
                };



                var options = new PaymentIntentCreateOptions
                {
                    Amount = Numerics.GetInt(_Amount * 100),
                    Currency = "usd",
                    PaymentMethodTypes = new List<string>
                      {
                        "card",
                      },
                    Customer = _CustomerID,
                    ApplicationFeeAmount = Numerics.GetInt(_ApplicationFee * 100),
                    TransferData = _PaymentIntentTransferDataOptions,
                    StatementDescriptor = ConfigurationManager.AppSettings["ConnectTheDock"], // should be only 22 character,
                    Description = _Description //optaional 
                };
                object response = service.Create(options);
                return response;

            }
            catch (StripeException e)
            {
                LogHelper.CreateLog(e.StripeError.Message);
                //return new StripeEphemerayKeyInput() ;
                return e.StripeError.Message;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex);
                return JsonResponse.GetResponse(ResponseCode.Exception, ex.Message);
                //return new StripeEphemerayKeyInput();
            }
        }

        public PaymentResponse CreateConnectMakePayment(decimal _Amount, string Nounce, string PaymentType, string _Description, string _Currency, string _StripeAccountId)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {

                if (_Currency == "US Dollar" || _Currency == "Euro"
                    || _Currency == "Sterling"
                    )
                {
                    _Currency = "usd";
                }

                Charge charge = new Charge();

                //Int64 _amount = Numerics.GetInt(amount * 100);

                decimal _ApplicationFee = _Amount * Convert.ToDecimal(ConfigurationManager.AppSettings["APP_Share"]);
                decimal _amountFeeDeduct = _Amount - (_Amount * Convert.ToDecimal(ConfigurationManager.AppSettings["APP_Share"]));

                if (PaymentType == "Card")
                {
                    var dataTrans = new ChargeTransferDataOptions
                    {
                        Amount = Numerics.GetInt(_amountFeeDeduct * 100),
                        Destination = _StripeAccountId//""
                    };

                    if (!String.IsNullOrEmpty(Nounce))
                    {
                        // This transaction is made using Nonce
                        var options = new ChargeCreateOptions
                        {
                            Amount = Numerics.GetInt(_Amount * 100),
                            //Currency = "usd",
                            Currency = _Currency,
                            Description = _Description,
                            Source = Nounce,
                            TransferData = dataTrans
                        };
                        var service = new ChargeService();
                        charge = service.Create(options);
                    }
                }
                _PaymentResponse.PaymentKey = charge.Id;
                _PaymentResponse.PaymentStatus = charge.Status;

                //_PaymentResponse.ErrorDescription = charge.des;
                _PaymentResponse.IsSuccess = true;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {

                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
        }


        //carete express connect account
        public PaymentResponse CreateConnectedAccountExpress(string _Email)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {



                var options = new AccountCreateOptions
                {
                    //Type = AccountType.Standard,
                    Type = "express",
                    Country = "US",
                    DefaultCurrency = "USD",
                    BusinessType = "individual",
                    Email = _Email
                };

                var service = new AccountService();
                Account account = service.Create(options);

                _PaymentResponse.PaymentKey = account.Id;
                _PaymentResponse.IsSuccess = true;

                return _PaymentResponse;
            }
            catch (StripeException ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
        }


        //create link for connected to account for on-boarding
        public PaymentResponse CreateLinkStripeConnectAccount(string _StripeAccountId)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {


                var options = new AccountLinkCreateOptions
                {
                    Account = _StripeAccountId,
                    RefreshUrl = ConfigurationManager.AppSettings["WebPath"] + "/Webhook/StripeLinkExpired",
                    ReturnUrl = ConfigurationManager.AppSettings["WebPath"] + "/Webhook/StripeWebHook?id=" + _StripeAccountId,
                    Type = "account_onboarding"

                };
                var service = new AccountLinkService();
                var res = service.Create(options);
                var resApi = res;
                _PaymentResponse.IsSuccess = true;
                _PaymentResponse.URL = resApi.Url; //https://connect.stripe.com/express/onboarding/hM0Dl6g1E3J7

                return _PaymentResponse;
            }
            catch (StripeException ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
        }

        //get the status of the connect account on boarding status
        public PaymentResponse GetStripeConnectAccountStatus(string _StripeAccountId)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {


                var service = new AccountService();
                var res = service.Get(_StripeAccountId);

                var resApi = res;
                if (resApi.PayoutsEnabled == true)
                {
                    _PaymentResponse.IsSuccess = true;
                }
                else
                {
                    _PaymentResponse.IsSuccess = false;
                }

                return _PaymentResponse;
            }
            catch (StripeException ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
        }


        //only for CTD
        public PaymentResponse CreateLinkStripeConnectAccount(string _StripeAccountId, bool IsWeb)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            string _callBackUrls = "";
            try
            {
                if (IsWeb == true)
                {
                    _callBackUrls = WebConfigurationManager.AppSettings["RedirectUrl"].ToString();
                }
                else
                {
                    _callBackUrls = WebConfigurationManager.AppSettings["WebPath"] + "/Webhook/StripeWebHook?id=" + _StripeAccountId;
                }
                /// var test = WebConfigurationManager.AppSettings["WebPath"].ToString();
                var options = new AccountLinkCreateOptions
                {
                    Account = _StripeAccountId,
                    //RefreshUrl = ConfigurationManager.AppSettings["WebPath"] + "/Webhook/StripeLinkExpired",
                    RefreshUrl = WebConfigurationManager.AppSettings["WebPath"] + "/Webhook/StripeLinkExpired",
                    //ReturnUrl = ConfigurationManager.AppSettings["WebPath"] + "/Webhook/StripeWebHook?id=" + _StripeAccountId,

                    //ReturnUrl = WebConfigurationManager.AppSettings["WebPath"] + "/Webhook/StripeWebHook?id=" + _StripeAccountId,
                    ReturnUrl = _callBackUrls,
                    Type = "account_onboarding"

                };
                var service = new AccountLinkService();
                var res = service.Create(options);
                var resApi = res;
                _PaymentResponse.IsSuccess = true;
                _PaymentResponse.URL = resApi.Url; //https://connect.stripe.com/express/onboarding/hM0Dl6g1E3J7

                return _PaymentResponse;
            }
            catch (StripeException ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
        }


        //use if you want to payout to connected account bank account from his available balance
        public PaymentResponse CreateConnectedAccountPayoutFrom(decimal _Amount, string _StripeAccountId, string _EventNote)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {

                //decimal _ApplicationFee = _Amount * Convert.ToDecimal(ConfigurationManager.AppSettings["APP_Share"]);
                //decimal _amount = _Amount - (_Amount * Convert.ToDecimal(ConfigurationManager.AppSettings["APP_Share"]));

                var options = new PayoutCreateOptions
                {
                    //Type = AccountType.Standard,
                    Amount = Numerics.GetInt(_Amount * 100),
                    Currency = "usd",
                    Description = _EventNote,
                };

                var _Request = new RequestOptions
                {
                    StripeAccount = _StripeAccountId,
                };

                var service = new PayoutService();
                Payout _Payout = service.Create(options, _Request);

                _PaymentResponse.PaymentKey = _Payout.Id;
                _PaymentResponse.PaymentStatus = _Payout.Status;
                _PaymentResponse.IsSuccess = true;

                return _PaymentResponse;
            }
            catch (StripeException ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.ErrorDescription = ex.Message;
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.ErrorDescription = ex.Message;
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
        }

        public PaymentResponse GetonnectedAccountPayoutStatus(string _PayoutID)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {


                var service = new PayoutService();
                Payout _Payout = service.Get(_PayoutID);

                _PaymentResponse.PaymentKey = _Payout.Id;
                _PaymentResponse.PaymentStatus = _Payout.Status; //paid//pending//in_transit//canceled//failed
                _PaymentResponse.IsSuccess = true;

                return _PaymentResponse;
            }
            catch (StripeException ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
        }

        //transfer the funds to one of your connected account
        public PaymentResponse CreateConnectedAccountTransfer(decimal _Amount, string _StripeAccountId, string _EventNote)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {

                //decimal _ApplicationFee = _Amount * Convert.ToDecimal(ConfigurationManager.AppSettings["APP_Share"]);
                //decimal _amount = _Amount - (_Amount * Convert.ToDecimal(ConfigurationManager.AppSettings["APP_Share"]));

                var options = new TransferCreateOptions
                {
                    //Type = AccountType.Standard,
                    Amount = Numerics.GetInt(_Amount * 100),
                    Currency = "usd",
                    Description = _EventNote,
                    Destination = _StripeAccountId
                };

                var _Request = new RequestOptions();


                var service = new TransferService();
                Transfer _Payout = service.Create(options, _Request);

                _PaymentResponse.PaymentKey = _Payout.Id;
                _PaymentResponse.PaymentStatus = _Payout.Object;
                _PaymentResponse.IsSuccess = true;

                return _PaymentResponse;
            }
            catch (StripeException ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.ErrorDescription = ex.Message;
                _PaymentResponse.PaymentStatus = ex.StripeError.Code;
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.ErrorDescription = ex.Message;
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
        }

        public PaymentResponse GetonnectedAccountTransferStatus(string _PayoutID)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {


                var service = new TransferService();
                Transfer _Payout = service.Get(_PayoutID);

                _PaymentResponse.PaymentKey = _Payout.Id;
                _PaymentResponse.PaymentStatus = _Payout.Object; //paid//pending//in_transit//canceled//failed
                _PaymentResponse.IsSuccess = true;

                return _PaymentResponse;
            }
            catch (StripeException ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                _PaymentResponse.ErrorDescription = ex.Message;
                return _PaymentResponse;
            }
        }


        public PaymentResponse CreateOwnBankPayout(decimal _Amount)
        {
            PaymentResponse _PaymentResponse = new PaymentResponse();
            try
            {



                var options = new PayoutCreateOptions
                {
                    //Type = AccountType.Standard,
                    Amount = Numerics.GetInt(_Amount * 100),
                    Currency = "usd",

                };


                var service = new PayoutService();
                Payout _Payout = service.Create(options);

                _PaymentResponse.PaymentKey = _Payout.Id;
                _PaymentResponse.PaymentStatus = _Payout.Status;
                _PaymentResponse.IsSuccess = true;

                return _PaymentResponse;
            }
            catch (StripeException ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                _PaymentResponse.IsSuccess = false;
                return _PaymentResponse;
            }
        }

        #endregion



        #region "Stripe Identity"

        public VerificationSessionMoodel CreateVerificationSession()
        {
            var model = new VerificationSessionMoodel();
            try
            {
                var service = new Stripe.Identity.VerificationSessionService();
                var _option = new Stripe.Identity.VerificationSessionCreateOptions()
                { 
                        Type= "document"
                };

                var _Payout = service.Create(_option);
                model.Id = _Payout.Id;
                model.Url = _Payout.Url;
                //model.Status = _Payout.Status;
                return model;
            }
            catch (StripeException ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                return null;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                return null;
            }
        }
        public VerificationSessionMoodel RetrieveVerificationStatus(string StripeIdentityId)
        {
            var model = new VerificationSessionMoodel();
            try
            {
                var service = new Stripe.Identity.VerificationSessionService();

                //var service = new VerificationSessionService();
                //service.Get("vs_1N42tK2eZvKYlo2CZ6AAahHc");
                //var _option = new Stripe.Identity.VerificationSessionCreateOptions()
                //{
                //    Type = "document"
                //};

                var _Payout = service.Get(StripeIdentityId);
                model.Id = _Payout.Id;
                model.Url = _Payout.Url;
                model.Status = _Payout.Status;
                //model.Status = _Payout.Status;
                return model;
            }
            catch (StripeException ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                return null;
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.PaymentGateway);
                return null;
            }
        }
        #endregion

        public class AssociatedObject
        {
            public string type { get; set; }
            public string id { get; set; }
        }
        public class EphemeralResponse
        {
            public string id { get; set; }
            public string @object { get; set; }
            public List<AssociatedObject> associated_objects { get; set; }
            public int created { get; set; }
            public int expires { get; set; }
            public bool livemode { get; set; }
            public string secret { get; set; }
        }
    }


}