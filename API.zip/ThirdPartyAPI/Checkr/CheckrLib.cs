﻿using Newtonsoft.Json.Linq;
using LawyerWatch.Library.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Script.Serialization;

namespace LawyerWatch.Library.ThirdPartyAPI.Checkr
{
    public class ObjectResponse
    {
        public string ObjectKey { get; set; }

        public string ErrorDescription { get; set; }

        public string ObjectStatus { get; set; }

        public Boolean IsSuccess { get; set; }
    }

    public class CheckrLib
    {
        ObjectResponse _obj;

        public CheckrLib()
        {
            _obj = new ObjectResponse();
        }


        //if (!String.IsNullOrEmpty(driverLicenseNumber) && !String.IsNullOrEmpty(driverLicenseState))
        //{
        //    package = WebConfigurationManager.AppSettings["Checkr_motor_vehicle_report"];
        //}
        //else if (!String.IsNullOrEmpty(ssn) && !String.IsNullOrEmpty(zipcode))
        //{
        //    package = WebConfigurationManager.AppSettings["Checkr_ssn_trace_report"];
        //}
        //else
        //{
        //package = WebConfigurationManager.AppSettings["Checkr_general_report"];


        public ObjectResponse CreateCandidateId(string FirstName, string LastName, string Email, string PhoneNumber, string BirthDate)
        {

            try
            {
                var httpWebRequest = (HttpWebRequest)WebRequest.Create("https://api.checkr.com/v1/candidates");
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                httpWebRequest.Headers.Add(HttpRequestHeader.AcceptCharset, "ISO-8859-1,utf-8");

                string username = WebConfigurationManager.AppSettings["Checkr_User"];
                string password = "";
                string svcCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));
                httpWebRequest.Headers.Add("Authorization", "Basic " + svcCredentials);

                const string middleName = "";
                string firstName = FirstName,
                    lastName = LastName,
                    email = Email,
                    phone = PhoneNumber,
                    //zipcode = data.ZipCode,
                    dob = Convert.ToDateTime(BirthDate).ToString("yyyy-MM-dd");
                //ssn = data.SSN,
                //driverLicenseNumber = data.LicenseNumber,
                //driverLicenseState = data.LicenseState;

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {

                    object obj = new
                    {
                        first_name = firstName,
                        middle_name = middleName,
                        no_middle_name = true,
                        last_name = lastName,
                        email = email,
                        phone = phone,
                        dob = dob,
                        //zipcode = zipcode,
                    };

                    //if (package == WebConfigurationManager.AppSettings["Checkr_ssn_trace_report"])
                    //{
                    //    obj = new
                    //    {
                    //        first_name = firstName,
                    //        middle_name = middleName,
                    //        no_middle_name = true,
                    //        last_name = lastName,
                    //        email = email,
                    //        phone = phone,
                    //        dob = dob,
                    //        zipcode = zipcode,
                    //        ssn = ssn
                    //    };
                    //}

                    //if (package == WebConfigurationManager.AppSettings["Checkr_motor_vehicle_report"])
                    //{
                    //    obj = new
                    //    {
                    //        first_name = firstName,
                    //        middle_name = middleName,
                    //        no_middle_name = true,
                    //        last_name = lastName,
                    //        email = email,
                    //        phone = phone,
                    //        dob = dob,
                    //        driver_license_number = driverLicenseNumber,
                    //        driver_license_state = driverLicenseState
                    //    };
                    //}

                    string json = new JavaScriptSerializer().Serialize(obj);

                    streamWriter.Write(json);
                }

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var jobject = JObject.Parse(result);
                    var candidateId = jobject["id"];
                    _obj.ObjectKey = candidateId.ToString();
                    _obj.IsSuccess = true;
                    return _obj;
                }

            }
            catch (WebException wex)
            {
                string error = "";
                _obj.IsSuccess = false;
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var jobject = JObject.Parse(error);

                            try
                            {
                                var jarray = (JArray)jobject["error"];
                                error = "" + (string)jarray[0];
                            }
                            catch
                            {
                                error = "" + (string)jobject["error"];
                            }
                        }
                    }
                }
                LogHelper.CreateLog(error, ErrorType.Checkr);
                _obj.ErrorDescription = error;
                return _obj;
            }
        }

        public ObjectResponse UpdateCandidateId(string candidateId, string PhoneNumber, string FirstName,
            string LastName, string LicenseNumber, string LicenseState, string ZipCode,
            string SSN)
        {
            try
            {
                string spotifyUrl = "https://api.checkr.com/v1/candidates/" + candidateId;

                var httpWebRequest = (HttpWebRequest)WebRequest.Create(spotifyUrl);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                httpWebRequest.Headers.Add(HttpRequestHeader.AcceptCharset, "ISO-8859-1,utf-8");
                //httpWebRequest.Headers.Add("Authorization",
                //    "Basic " + WebConfigurationManager.AppSettings["Checkr_User"]select * from );

                string username = WebConfigurationManager.AppSettings["Checkr_User"];
                string password = "";
                string svcCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));
                httpWebRequest.Headers.Add("Authorization", "Basic " + svcCredentials);

                string
                    phone = PhoneNumber;
                //zipcode = data.ZipCode,
                //dob = Convert.ToDateTime(BirthDate).ToString("yyyy-MM-dd");

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {

                    object obj = new
                    {
                        phone = phone,
                        //dob = Convert.ToDateTime(BirthDate).ToString("yyyy-MM-dd"),
                        first_name = FirstName,
                        last_name = LastName,
                        zipcode = ZipCode,
                        ssn = SSN,
                        driver_license_number = LicenseNumber,
                        driver_license_state = LicenseState,
                    };


                    string json = new JavaScriptSerializer().Serialize(obj);

                    streamWriter.Write(json);
                }

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var jobject = JObject.Parse(result);
                    var candidateid = jobject["id"];
                    _obj.ObjectKey = candidateid.ToString();
                    _obj.IsSuccess = true;
                    return _obj;
                }

            }
            catch (WebException wex)
            {
                string error = "";
                _obj.IsSuccess = false;
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var jobject = JObject.Parse(error);

                            try
                            {
                                var jarray = (JArray)jobject["error"];
                                error = "" + (string)jarray[0];
                            }
                            catch
                            {
                                error = "" + (string)jobject["error"];
                            }
                        }
                    }
                }
                _obj.ErrorDescription = error;
                return _obj;
            }
        }

        public ObjectResponse CreateInvitation(string candidateId, string package,
            string FullName, string Email)
        {

            try
            {
                var httpWebRequest = (HttpWebRequest)WebRequest.Create("https://api.checkr.com/v1/invitations");
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                httpWebRequest.Headers.Add(HttpRequestHeader.AcceptCharset, "ISO-8859-1,utf-8");
                string username = WebConfigurationManager.AppSettings["Checkr_User"];
                string password = "";
                string svcCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));
                httpWebRequest.Headers.Add("Authorization", "Basic " + svcCredentials);

                List<WorkLocation> wL = new List<WorkLocation>();
                wL.Add(new WorkLocation
                {
                    state = "FL"
                });
                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json = new JavaScriptSerializer().Serialize(new
                    {
                        candidate_id = candidateId,
                        package = package,
                        work_locations = wL
                    });
                    LogHelper.CreateLog(json);
                    streamWriter.Write(json);
                }

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader2 = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader2.ReadToEnd();
                    var jobject = JObject.Parse(result);
                    var InvitationID = jobject["id"];
                    var InvitationStatus = jobject["status"];
                    var _invitation_url = jobject["invitation_url"];

                    _obj.ObjectKey = InvitationID.ToString();
                    _obj.ObjectStatus = InvitationStatus.ToString();

                    SendCheckrBackgroundTemplateInvitationEmail(FullName, Email, "Checker", _invitation_url.ToString());

                }
                _obj.IsSuccess = true;

                SendCheckrBackgroundTemplateEmail(FullName, Email, "Checker");


                return _obj;

            }
            catch (WebException wex)
            {
                string error = "";
                _obj.IsSuccess = false;
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var jobject = JObject.Parse(error);

                            try
                            {
                                var jarray = (JArray)jobject["error"];
                                error = "" + (string)jarray[0];
                            }
                            catch
                            {
                                error = "" + (string)jobject["error"];
                            }
                        }
                    }
                }
                _obj.ErrorDescription = error;
                return _obj;
            }
        }


        public ObjectResponse GetInvitationtStatus(string invitationid)
        {

            try
            {
                string spotifyUrl = "https://api.checkr.com/v1/invitations/" + invitationid;
                HttpWebRequest httpWebRequest;
                httpWebRequest = (HttpWebRequest)WebRequest.Create(spotifyUrl);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "GET";
                httpWebRequest.Headers.Add(HttpRequestHeader.AcceptCharset, "ISO-8859-1,utf-8");
                string username = WebConfigurationManager.AppSettings["Checkr_User"];
                string password = "";
                string svcCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));
                httpWebRequest.Headers.Add("Authorization", "Basic " + svcCredentials);

                var status = "";
                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var jobject = JObject.Parse(result);
                    status = (string)jobject["status"];
                }
                _obj.ObjectStatus = status; //completed//expired//pending
                _obj.IsSuccess = true;
                return _obj;
            }
            catch (WebException wex)
            {
                string error = "";
                _obj.IsSuccess = false;
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var jobject = JObject.Parse(error);

                            try
                            {
                                var jarray = (JArray)jobject["error"];
                                error = "" + (string)jarray[0];
                            }
                            catch
                            {
                                error = "" + (string)jobject["error"];
                            }
                        }
                    }
                }
                _obj.ErrorDescription = error;
                return _obj;
            }

        }


        public ObjectResponse CreateReport(string candidateid, string package)
        {
            try
            {
                HttpWebRequest httpWebRequest;

                httpWebRequest = (HttpWebRequest)WebRequest.Create("https://api.checkr.com/v1/reports");
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "POST";
                httpWebRequest.Headers.Add(HttpRequestHeader.AcceptCharset, "ISO-8859-1,utf-8");
                string username = WebConfigurationManager.AppSettings["Checkr_User"];
                string password = "";
                string svcCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));
                httpWebRequest.Headers.Add("Authorization", "Basic " + svcCredentials);

                using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                {
                    string json = new JavaScriptSerializer().Serialize(new
                    {
                        candidate_id = candidateid,
                        package = package
                    });

                    streamWriter.Write(json);
                }


                var ReportID = "";
                var status = "";

                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var jobject = JObject.Parse(result);
                    ReportID = (string)jobject["id"];
                    status = (string)jobject["result"];



                }
                _obj.ObjectKey = ReportID;
                _obj.ObjectStatus = status; //clear//consider
                _obj.IsSuccess = true;
                return _obj;

            }
            catch (WebException wex)
            {
                string error = "";
                _obj.IsSuccess = false;
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var jobject = JObject.Parse(error);

                            try
                            {
                                var jarray = (JArray)jobject["error"];
                                error = "" + (string)jarray[0];
                            }
                            catch
                            {
                                error = "" + (string)jobject["error"];
                            }
                        }
                    }
                }
                _obj.ErrorDescription = error;
                return _obj;
            }

        }

        public ObjectResponse GetReportStatus(string reportid)
        {
            try
            {

                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                string spotifyUrl = "https://api.checkr.com/v1/reports/" + reportid;
                HttpWebRequest httpWebRequest;
                httpWebRequest = (HttpWebRequest)WebRequest.Create(spotifyUrl);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "GET";
                httpWebRequest.Headers.Add(HttpRequestHeader.AcceptCharset, "ISO-8859-1,utf-8");
                string username = WebConfigurationManager.AppSettings["Checkr_User"];
                string password = "";
                string svcCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));
                httpWebRequest.Headers.Add("Authorization", "Basic " + svcCredentials);

                var status = "";
                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var jobject = JObject.Parse(result);
                    status = (string)jobject["result"];

                    if (status == "" || status == null)
                    {
                        status = (string)jobject["status"];
                    }

                    _obj.ObjectStatus = status; //clear//consider

                }
                _obj.IsSuccess = true;
                return _obj;
            }
            catch (WebException wex)
            {
                string error = "";
                _obj.IsSuccess = false;
                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var jobject = JObject.Parse(error);

                            try
                            {
                                var jarray = (JArray)jobject["error"];
                                error = "" + (string)jarray[0];
                            }
                            catch
                            {
                                error = "" + (string)jobject["error"];
                            }
                        }
                    }
                }
                _obj.ErrorDescription = error;
                return _obj;
            }
        }

        public ObjectResponse GetCandidatesReport(string CandidateID)
        {
            try
            {

                string spotifyUrl = "https://api.checkr.com/v1/candidates/" + CandidateID;
                HttpWebRequest httpWebRequest;
                httpWebRequest = (HttpWebRequest)WebRequest.Create(spotifyUrl);
                httpWebRequest.ContentType = "application/json";
                httpWebRequest.Method = "GET";
                httpWebRequest.Headers.Add(HttpRequestHeader.AcceptCharset, "ISO-8859-1,utf-8");
                string username = WebConfigurationManager.AppSettings["Checkr_User"];
                string password = "";
                string svcCredentials = Convert.ToBase64String(ASCIIEncoding.ASCII.GetBytes(username + ":" + password));
                httpWebRequest.Headers.Add("Authorization", "Basic " + svcCredentials);

                var reportId = "";
                var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                {
                    var result = streamReader.ReadToEnd();
                    var jobject = JObject.Parse(result);
                    var jarray = (JArray)jobject["report_ids"];

                    if (jarray.Count > 0)
                    {
                        var _reportId = (string)jarray[0]; ;
                        reportId = _reportId;
                    }
                }
                _obj.ObjectKey = reportId;
                _obj.IsSuccess = true;
                return _obj;
            }
            catch (WebException wex)
            {
                string error = "";
                _obj.IsSuccess = false;

                if (wex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)wex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            error = reader.ReadToEnd();
                            var jobject = JObject.Parse(error);

                            try
                            {
                                var jarray = (JArray)jobject["error"];
                                error = "" + (string)jarray[0];
                            }
                            catch
                            {
                                error = "" + (string)jobject["error"];
                            }
                        }
                    }
                }
                _obj.ErrorDescription = error;
                return _obj;
            }

        }



        #region "Send Emails"

        public void SendCheckrBackgroundTemplateEmail(string name, string email, string status)
        {
            string subject = WebConfigurationManager.AppSettings["AppName"] + " - Application Status Update";

            string body = "Hello " + name + ", <br/> ";
            //body += "Congratulations on passing your virtual interview!<br/><br/>";
            body += "<br/>";

            body += "We have sent you an invitation to your background check in a separate email. Don’t worry, the background check has been paid by " + WebConfigurationManager.AppSettings["AppName"] + " for your convenience!<br/><br/>";
            body += "This process can take up to 2 weeks, but we will try our best to get back to you sooner. Once the background check has cleared, you will be contacted by one of our staff members.<br/><br/>";
            body += "If you have any questions or concerns, please feel free to <a href='mailto:" + WebConfigurationManager.AppSettings["Support_EMAIL"] + "'>contact us.</a><br/><br/>";
            body += "We thank you again for your interest in " + WebConfigurationManager.AppSettings["AppName"] + " and hope to hear from you soon.<br/>";

            body += "Sincerely,<br/>";
            body += WebConfigurationManager.AppSettings["AppName"] + " Team";

            EmailHelper.SendEmail(email, subject, body);

        }

        public void SendCheckrBackgroundTemplateInvitationEmail(string name, string email, string status, string _invitationLink)
        {
            string subject = WebConfigurationManager.AppSettings["AppName"] + " - Checkr invitation link";

            string body = "Hello " + name + ", <br/> ";

            body += "<br/>";

            body += "here is your checkr link  " + _invitationLink + "<br/><br/>";

            body += " Don’t worry, the background check has been paid by " + WebConfigurationManager.AppSettings["AppName"] + " for your convenience!<br/><br/>";
            body += "This process can take up to 2 weeks, but we will try our best to get back to you sooner. Once the background check has cleared, you will be contacted by one of our staff members.<br/><br/>";
            body += "If you have any questions or concerns, please feel free to <a href='mailto:" + WebConfigurationManager.AppSettings["Support_EMAIL"] + "'>contact us.</a><br/><br/>";
            body += "We thank you again for your interest in " + WebConfigurationManager.AppSettings["AppName"] + " and hope to hear from you soon.<br/>";

            body += "Sincerely,<br/>";
            body += WebConfigurationManager.AppSettings["AppName"] + " Team";

            EmailHelper.SendEmail(email, subject, body);

        }

        #endregion


    }
    public class WorkLocation
    {

        public string state { get; set; }
    }
}
