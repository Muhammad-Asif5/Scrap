﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LawyerWatch.Library.Utilities
{
    public class UtcConversion
    {
        public static long FLocalToUTCOffset(long deviceutcoffset)
        {
            long UTCOffset = 0;
            long UTCOffsetMin = 0;
            UTCOffset = (deviceutcoffset / 100) * -1;
            UTCOffsetMin = Convert.ToInt32(((Convert.ToDecimal(deviceutcoffset) / 100) % 1) * 100);
            if (UTCOffset < 0)
            {
                return -((Math.Abs(@UTCOffset) * 60) + Math.Abs(@UTCOffsetMin));
            }
            else
            {
                return (Math.Abs(@UTCOffset) * 60) + Math.Abs(@UTCOffsetMin);
            }
        }

        public static long FUTCToLocalOffset(long deviceutcoffset)
        {
            long UTCOffset = 0;
            long UTCOffsetMin = 0;
            UTCOffset = (deviceutcoffset / 100) * 1;
            UTCOffsetMin = Convert.ToInt32(((Convert.ToDecimal(deviceutcoffset) / 100) % 1) * 100);
            if (UTCOffset < 0)
            {
                return -((Math.Abs(UTCOffset) * 60) + Math.Abs(UTCOffsetMin));
            }
            else
            {
                return (Math.Abs(@UTCOffset) * 60) + Math.Abs(@UTCOffsetMin);
            }
        }

        public static DateTime FLocalToUTC(long uTCOffset, DateTime dateTime)
        {
            return dateTime.AddMinutes(uTCOffset);
        }

        public static DateTime FUTCToLocal(long uTCOffset, DateTime dateTime)
        {
            return dateTime.AddMinutes(uTCOffset);
        }
    }
}
