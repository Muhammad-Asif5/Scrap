﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace LawyerWatch.Library.Utilities
{
    public enum ErrorType
    {
        StoreProcedure,
        Notification,
        Schedular,
        System,
        User,
        PaymentGateway,
        Exception,
        APILog,
        Checkr,
        APIThrottleLog,
        Twillio
    }

    public static class LogHelper
    {

        /// <summary>
        /// LogHelper.CreateLogWithRequest(ex, Request);
        /// </summary>
        /// <param name="ex"></param>
        /// <param name="Request"></param>
        /// <param name="_ErrorType"></param>
        /// <returns></returns>
        public static Boolean CreateLogWithRequest(Exception ex, HttpRequestMessage Request, ErrorType _ErrorType = ErrorType.Exception)
        {

            //if (Convert.ToBoolean(WebConfigurationManager.AppSettings["Logger"].ToString()) == false && ErrorType.Exception != _ErrorType)
            if (Convert.ToBoolean(WebConfigurationManager.AppSettings["Logger"].ToString()) == false)
            {
                return false;
            }


            try
            {

                string filePath = "";

                if (ErrorType.Exception == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\ExceptionLog.txt";
                }
                else if (ErrorType.User == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\UserLog.txt";
                }
                else if (ErrorType.StoreProcedure == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\StoreProcedure.txt";
                }
                else if (ErrorType.Notification == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Notification.txt";
                }
                else if (ErrorType.PaymentGateway == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\PaymentGateway.txt";
                }
                else if (ErrorType.Schedular == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Schedular.txt";
                }


                Helper.CreateDirectories(ConfigurationManager.AppSettings["LogFilePath"]);

                string _otherstuff = "";

                try
                {
                    HttpContent requestContent = Request.Content;
                    string jsonContent = requestContent.ReadAsStringAsync().Result;
                    Request.RequestUri.ToString();


                    _otherstuff = "REQUST : " + Request.RequestUri.ToString() + " BODY :" + jsonContent.ToString() + " ";
                }
                catch
                {
                }

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("" + _otherstuff + "Message :" + ex.Message + " TargetSite: " + ex.TargetSite.ToString() + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                else
                {
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        string _innerexception = (ex.InnerException == null) ? "" : ex.InnerException.ToString();

                        writer.WriteLine("" + _otherstuff + "Inner :" + _innerexception + " Message :" + ex.Message + " TargetSite: " + ex.TargetSite.ToString() + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }

                }

                return true;
            }
            catch
            {

                return false;
            }





        }



        public static async Task<Boolean> CreateLogAsync(Exception ex, ErrorType _ErrorType = ErrorType.Exception)
        {

            //if (Convert.ToBoolean(WebConfigurationManager.AppSettings["Logger"].ToString()) == false && ErrorType.Exception != _ErrorType)
            if (Convert.ToBoolean(WebConfigurationManager.AppSettings["Logger"].ToString()) == false)
            {
                return false;
            }

            return await Task.Factory.StartNew(() =>
            {

                try
                {

                    string filePath = "";

                    if (ErrorType.Exception == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\ExceptionLog.txt";
                    }
                    else if (ErrorType.User == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\UserLog.txt";
                    }
                    else if (ErrorType.StoreProcedure == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\StoreProcedure.txt";
                    }
                    else if (ErrorType.Notification == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Notification.txt";
                    }
                    else if (ErrorType.PaymentGateway == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\PaymentGateway.txt";
                    }
                    else if (ErrorType.Schedular == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Schedular.txt";
                    }

                    Helper.CreateDirectories(ConfigurationManager.AppSettings["LogFilePath"]);

                    if (!File.Exists(filePath))
                    {
                        File.Create(filePath).Dispose();
                        using (StreamWriter writer = new StreamWriter(filePath, true))
                        {
                            writer.WriteLine("Message :" + ex.Message + " TargetSite: " + ex.TargetSite.ToString() + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                            writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                        }
                    }
                    else
                    {
                        using (StreamWriter writer = new StreamWriter(filePath, true))
                        {
                            writer.WriteLine("Message :" + ex.Message + " TargetSite: " + ex.TargetSite.ToString() + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                            writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                        }

                    }

                    return true;
                }
                catch
                {

                    return false;
                }


            });


        }

        public static Boolean CreateLog(Exception ex, ErrorType _ErrorType = ErrorType.Exception)
        {

            //if (Convert.ToBoolean(WebConfigurationManager.AppSettings["Logger"].ToString()) == false && ErrorType.Exception != _ErrorType)
            if (Convert.ToBoolean(WebConfigurationManager.AppSettings["Logger"].ToString()) == false)
            {
                return false;
            }

            if (ex.Message != null)
            {
                if (ex.Message.Contains("**Sql**"))
                {
                    return true;
                }
            }
            try
            {

                string filePath = "";

                if (ErrorType.Exception == _ErrorType)
                {

                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\ExceptionLog.txt";
                }
                else if (ErrorType.User == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\UserLog.txt";
                }
                else if (ErrorType.StoreProcedure == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\StoreProcedure.txt";
                }
                else if (ErrorType.Notification == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Notification.txt";
                }
                else if (ErrorType.PaymentGateway == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\PaymentGateway.txt";
                }
                else if (ErrorType.Schedular == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Schedular.txt";
                }
                else if (ErrorType.Twillio == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Twillio.txt";
                }


                Helper.CreateDirectories(ConfigurationManager.AppSettings["LogFilePath"]);

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        //var s = new StackTrace(ex);
                        //var thisasm = Assembly.GetExecutingAssembly();
                        //var methodname = s.GetFrames().Select(f => f.GetMethod()).First(m => m.Module.Assembly == thisasm).Name;

                        writer.WriteLine("Message :" + ex.Message + " Method: " + ex.ToString() + " TargetSite: " + ex.TargetSite.ToString() + ex.TargetSite + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                else
                {
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        //var s = new StackTrace(ex);
                        //var thisasm = Assembly.GetExecutingAssembly();
                        //var methodname = s.GetFrames().Select(f => f.GetMethod()).First(m => m.Module.Assembly == thisasm).Name;

                        writer.WriteLine("Message :" + ex.Message + " Method: " + ex.ToString() + " TargetSite: " + ex.TargetSite.ToString() + ex.TargetSite + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }

                }

                return true;
            }
            catch
            {

                return false;
            }





        }

        public static async Task<Boolean> CreateLogAsync(string logmessage, ErrorType _ErrorType = ErrorType.User)
        {
            //if (Convert.ToBoolean(WebConfigurationManager.AppSettings["Logger"].ToString()) == false && ErrorType.Exception != _ErrorType)
            if (Convert.ToBoolean(WebConfigurationManager.AppSettings["Logger"].ToString()) == false)
            {
                return false;
            }

            return await Task.Factory.StartNew(() =>
            {

                try
                {
                    string filePath = "";

                    if (ErrorType.Exception == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\ExceptionLog.txt";
                    }
                    else if (ErrorType.User == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\UserLog.txt";
                    }
                    else if (ErrorType.StoreProcedure == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\StoreProcedure.txt";
                    }
                    else if (ErrorType.Notification == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Notification.txt";
                    }
                    else if (ErrorType.PaymentGateway == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\PaymentGateway.txt";
                    }
                    else if (ErrorType.Schedular == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Schedular.txt";
                    }
                    else if (ErrorType.Twillio == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Twillio.txt";
                    }

                    Helper.CreateDirectories(ConfigurationManager.AppSettings["LogFilePath"]);

                    if (!File.Exists(filePath))
                    {
                        File.Create(filePath).Dispose();

                        using (StreamWriter writer = new StreamWriter(filePath, true))
                        {
                            writer.WriteLine("Message :" + logmessage.ToString() + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                            writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                        }
                    }
                    else
                    {

                        using (StreamWriter writer = new StreamWriter(filePath, true))
                        {
                            writer.WriteLine("Message :" + logmessage.ToString() + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                            writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                        }
                    }

                    return true;

                }
                catch
                {
                    return false;

                }


            });

        }

        public static Boolean CreateLog(string logmessage, ErrorType _ErrorType = ErrorType.User)
        {
            //if (Convert.ToBoolean(WebConfigurationManager.AppSettings["Logger"].ToString()) == false && ErrorType.Exception != _ErrorType)
            if (Convert.ToBoolean(WebConfigurationManager.AppSettings["Logger"].ToString()) == false)
            {
                return false;
            }



            try
            {
                string filePath = "";

                if (ErrorType.Exception == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\ExceptionLog.txt";
                }
                else if (ErrorType.User == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\UserLog.txt";
                }
                else if (ErrorType.StoreProcedure == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\StoreProcedure.txt";
                }
                else if (ErrorType.Notification == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Notification.txt";
                }
                else if (ErrorType.PaymentGateway == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\PaymentGateway.txt";
                }
                else if (ErrorType.System == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\System.txt";
                }
                else if (ErrorType.Schedular == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Schedular.txt";
                }
                else if (ErrorType.Twillio == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Twillio.txt";
                }
                else if (ErrorType.Checkr == _ErrorType)
                {
                    filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\Checkr.txt";
                }

                Helper.CreateDirectories(ConfigurationManager.AppSettings["LogFilePath"]);

                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();

                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + logmessage.ToString() + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }
                else
                {

                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine("Message :" + logmessage.ToString() + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                        writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    }
                }

                return true;

            }
            catch
            {
                return false;

            }



        }


        /// <summary>
        /// LogHelper.CreateAPILog("AddSearch", JsonConvert.SerializeObject(input).ToString(), ErrorType.APILog);
        /// 
        /// </summary>
        /// <param name="Api"></param>
        /// <param name="logmessage"></param>
        /// <param name="_ErrorType"></param>
        /// <returns></returns>
        public static async Task<Boolean> CreateAPILogAsync(string Info, string Api, string logmessage, ErrorType _ErrorType = ErrorType.User)
        {


            if (Convert.ToBoolean(WebConfigurationManager.AppSettings["APILogger"].ToString()) == false)
            {
                return false;
            }

            return await Task.Factory.StartNew(() =>
            {

                try
                {
                    string filePath = "";
                    string _Readvalue = "";

                    if (ErrorType.APILog == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\APILog.txt";
                    }

                    Helper.CreateDirectories(ConfigurationManager.AppSettings["LogFilePath"]);

                    if (File.Exists(filePath))
                    {
                        _Readvalue = File.ReadAllText(filePath);
                    }

                    if (!_Readvalue.Contains(Api))
                    {
                        if (!File.Exists(filePath))
                        {
                            File.Create(filePath).Dispose();

                            using (StreamWriter writer = new StreamWriter(filePath, true))
                            {
                                writer.WriteLine(Info + " : " + logmessage.ToString() + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                                writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                            }
                        }
                        else
                        {

                            using (StreamWriter writer = new StreamWriter(filePath, true))
                            {
                                writer.WriteLine(Info + " : " + logmessage.ToString() + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                                writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                            }
                        }
                    }

                    return true;

                }
                catch
                {
                    return false;

                }


            });

        }

        /// <summary>
        /// LogHelper.CreateAPILog("AddSearch", JsonConvert.SerializeObject(input).ToString(), ErrorType.APILog);
        /// 
        /// </summary>
        /// <param name="Api"></param>
        /// <param name="logmessage"></param>
        /// <param name="_ErrorType"></param>
        /// <returns></returns>
        public static Boolean CreateAPILog(string Info, string Api, string logmessage,
            string _IPAddress,
            string _UserAgent,
            ErrorType _ErrorType = ErrorType.User)
        {


            if (Convert.ToBoolean(WebConfigurationManager.AppSettings["APILogger"].ToString()) == false)
            {
                return false;
            }



            try
            {
                string filePath = "";
                string _Readvalue = "";
                //string _CurrentDate = _UserAgent + "_";
                string _CurrentDate = "";

                if (Convert.ToBoolean(WebConfigurationManager.AppSettings["APILoggerUseDate"].ToString()) == true)
                {
                    _CurrentDate = _CurrentDate + DateTime.UtcNow.ToString("dd") + DateTime.UtcNow.ToString("MMM") + DateTime.UtcNow.ToString("yy") + "_";
                }

                if (Convert.ToBoolean(WebConfigurationManager.AppSettings["APILoggerUseIPAddress"].ToString()) == false)
                {
                    if (ErrorType.APILog == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\" + _CurrentDate + "APILog.txt";
                    }

                    if (ErrorType.APIThrottleLog == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\" + _CurrentDate + "APIThrottleLog.txt";
                    }

                }
                else
                {
                    if (ErrorType.APILog == _ErrorType)
                    {
                        filePath = ConfigurationManager.AppSettings["LogFilePath"] + "\\" + _CurrentDate + _IPAddress + "_APILog.txt";
                    }
                }

                Helper.CreateDirectories(ConfigurationManager.AppSettings["LogFilePath"]);

                //if (File.Exists(filePath))
                //{
                //    _Readvalue = File.ReadAllText(filePath);
                //}

                //if (!_Readvalue.Contains(Api))
                //{
                if (!File.Exists(filePath))
                {
                    File.Create(filePath).Dispose();

                    using (FileStream writer = File.Open(filePath, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                    {
                        using (StreamWriter sw = new StreamWriter(writer))
                        {
                            sw.WriteLine(Info + " : " + logmessage.ToString() + Environment.NewLine + "Date :" + DateTime.UtcNow.ToString());
                            sw.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                        }
                    }

                    //using (StreamWriter writer = new StreamWriter(filePath, true))
                    //{
                    //    writer.WriteLine(Info + " : " + logmessage.ToString() + Environment.NewLine + "Date :" + DateTime.Now.ToString());
                    //    writer.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                    //}
                }
                else
                {

                    using (FileStream writer = File.Open(filePath, FileMode.Append, FileAccess.Write, FileShare.ReadWrite))
                    {
                        using (StreamWriter sw = new StreamWriter(writer))
                        {
                            sw.WriteLine(Info + " : " + logmessage.ToString() + Environment.NewLine + "Date :" + DateTime.UtcNow.ToString());
                            sw.WriteLine(Environment.NewLine + "-----------------------------------------------------------------------------" + Environment.NewLine);
                        }
                    }
                }
                //}

                return true;

            }
            catch (Exception ex)
            {
                CreateLog(ex);
                return false;

            }




        }
    }
}
