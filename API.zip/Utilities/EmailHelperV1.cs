﻿using LawyerWatch.Library.Validations;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace LawyerWatch.Library.Utilities
{
    public static class EmailHelperV1
    {
        public static string SendGridApiKey
        {
            get { return ConfigurationManager.AppSettings["SendGridApiKey"].ToString(); }
        }
        public static string AdminEmail
        {
            get { return ConfigurationManager.AppSettings["ADMIN_EMAIL"].ToString(); }
        }
        public static string AppName
        {
            get { return WebConfigurationManager.AppSettings["AppName"].ToString(); }
        }
        public static string IsSendGridConfiguration
        {
            get { return WebConfigurationManager.AppSettings["IsSendGridConfiguration"].ToString(); }
        }

        public static void SendEmail(string To, string Subject, string BodyText)
        {
            if (IsSendGridConfiguration == "1")
            {
                SendGridEmailAsync(To, Subject, BodyText);
            }
            else
            {
                SendEmailAsync(To, Subject, BodyText);
            }
        }
        public static void SendEmail(string To, string Subject, string BodyText, string AttachmentURL)
        {
            if (IsSendGridConfiguration == "1")
            {
                SendGridEmailAttachment(To, Subject, BodyText, AttachmentURL);
            }
            else
            {
                SendEmailAttachment(To, Subject, BodyText, AttachmentURL);
            }
        }

        public static async Task<string> SendGridEmailAsync(string To, string Subject, string BodyText)
        {
            try
            {
                string Api = SendGridApiKey;
                var apiKey = Environment.GetEnvironmentVariable(Api);
                var client = new SendGridClient(Api);
                var msg = new SendGridMessage()
                {
                    From = new EmailAddress(AdminEmail, AppName),
                    Subject = Subject,
                    HtmlContent = BodyText
                };
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                msg.AddTo(new EmailAddress(To));
                var response = await client.SendEmailAsync(msg);

                // A success status code means SendGrid received the email request and will process it.
                // Errors can still occur when SendGrid tries to send the email. 
                // If email is not received, use this URL to debug: https://app.sendgrid.com/email_activity 
                return response.IsSuccessStatusCode ? "Email queued successfully!" : "Something went wrong!";
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.Exception);
                return ex.Message;
            }

        }
        public static string SendGridEmailAttachment(string To, string Subject, string BodyText, string FileURL)
        {
            try
            {
                using (var wc = new System.Net.WebClient())
                {
                    var File = wc.DownloadData(FileURL);
                    string Api = SendGridApiKey;

                    var apiKey = Environment.GetEnvironmentVariable(Api);
                    var client = new SendGridClient(Api);
                    var msg = new SendGridMessage()
                    {
                        From = new EmailAddress(AdminEmail, AppName),
                        Subject = Subject,
                        HtmlContent = BodyText
                    };
                    msg.AddTo(new EmailAddress(To));
                    msg.AddAttachmentAsync(GetFileName(FileURL), GetStreamFromUrl(FileURL));
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    var response = client.SendEmailAsync(msg);
                    // A success status code means SendGrid received the email request and will process it.
                    // Errors can still occur when SendGrid tries to send the email. 
                    // If email is not received, use this URL to debug: https://app.sendgrid.com/email_activity 
                    return response.Result.IsSuccessStatusCode ? "Email queued successfully!" : "Something went wrong!";
                }
            }
            catch (Exception ex)
            {
                LogHelper.CreateLog(ex, ErrorType.Exception);
                return ex.Message;
            }
        }
        public static async Task<string> SendEmailAsync(string To, string Subject, string BodyText)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (FValidations.IsValidEmail(To))
                {
                    MailMessage mailMessage = new MailMessage(AdminEmail, To, Subject, BodyText);
                    MailAddress Reply = new MailAddress(AdminEmail, "relay", System.Text.Encoding.UTF8);
                    mailMessage.ReplyTo = Reply;
                    SmtpClient smtp = new SmtpClient();
                    try
                    {
                        mailMessage.IsBodyHtml = true;
                        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                        smtp.Send(mailMessage);
                        return "Success";
                    }
                    catch (Exception ex)
                    {
                        LogHelper.CreateLog(ex, ErrorType.Exception);
                        return "Error";

                    }
                    finally
                    {
                        mailMessage.Dispose();
                        smtp = null;
                    }
                }
                else
                {
                    return "Invalid EmailAddress";
                }
            });

        }

        public static string SendEmailAttachment(string To, string Subject, string BodyText, string FileURL)
        {

            if (FValidations.IsValidEmail(To))
            {
                MailMessage mailMessage = new MailMessage(AdminEmail, To, Subject, BodyText);
                MailAddress Reply = new MailAddress(AdminEmail, "relay", System.Text.Encoding.UTF8);
                mailMessage.ReplyTo = Reply;
                SmtpClient smtp = new SmtpClient();
                try
                {
                    mailMessage.IsBodyHtml = true;
                    System.Net.Mail.Attachment attachment;
                    attachment = new System.Net.Mail.Attachment(FileURL);
                    mailMessage.Attachments.Add(attachment);
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    smtp.Send(mailMessage);
                    return "Success";
                }
                catch (Exception ex)
                {
                    LogHelper.CreateLog(ex, ErrorType.Exception);
                    return "Error";
                }
                finally
                {
                    mailMessage.Dispose();
                    smtp = null;
                }
            }
            else
            {
                return "Invalid EmailAddress";
            }

        }
        public static string GetFileName(string hreflink)
        {
            Uri uri = new Uri(hreflink);
            string filename = "";
            if (uri.IsFile)
            {
                filename = System.IO.Path.GetFileName(uri.LocalPath);
            }
            return filename;
        }
        private static Stream GetStreamFromUrl(string url)
        {
            byte[] imageData = null;

            using (var wc = new System.Net.WebClient())
                imageData = wc.DownloadData(url);

            return new MemoryStream(imageData);
        }
    }
}
