﻿using LawyerWatch.Library.Validations;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Hosting;

namespace LawyerWatch.Library.Utilities
{
    public static class EmailHelper
    {

        public static string SendEmail(string To, string Subject, string BodyText, bool IsSaveEmail = false)
        {

            if (FValidations.IsValidEmail(To))
            {
                BodyText = StandardEmail.AddHeaderFooter(BodyText);
                MailMessage mailMessage = new MailMessage(ConfigurationManager.AppSettings["ADMIN_EMAIL"].ToString(), To, Subject, BodyText);
                MailAddress Reply = new MailAddress(ConfigurationManager.AppSettings["ADMIN_EMAIL"].ToString(), "relay", System.Text.Encoding.UTF8);
                mailMessage.ReplyTo = Reply;
                if (IsSaveEmail)
                {
                    mailMessage.CC.Add(new MailAddress(ConfigurationManager.AppSettings["ADMIN_EMAIL"].ToString(), "relay", System.Text.Encoding.UTF8));
                }


                SmtpClient smtp = new SmtpClient();
                try
                {

                    mailMessage.IsBodyHtml = true;
                    smtp.Timeout = 10000;
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                    smtp.Send(mailMessage);

                    return "Success";
                }
                catch (Exception ex)
                {
                    LogHelper.CreateLog(ex, ErrorType.Exception);
                    return "Error";
                }
                finally
                {
                    mailMessage.Dispose();
                    smtp = null;
                }
            }
            else
            {
                return "Invalid EmailAddress";
            }

        }

        public static string SendEmailAttachment(string To, string Subject, string BodyText, string FileURL)
        {

            if (FValidations.IsValidEmail(To))
            {
                BodyText = StandardEmail.AddHeaderFooter(BodyText);
                MailMessage mailMessage = new MailMessage(ConfigurationManager.AppSettings["ADMIN_EMAIL"].ToString(), To, Subject, BodyText);
                MailAddress Reply = new MailAddress(ConfigurationManager.AppSettings["ADMIN_EMAIL"].ToString(), "relay", System.Text.Encoding.UTF8);
                mailMessage.ReplyTo = Reply;


                SmtpClient smtp = new SmtpClient();
                try
                {

                    mailMessage.IsBodyHtml = true;

                    System.Net.Mail.Attachment attachment;
                    attachment = new System.Net.Mail.Attachment(FileURL);
                    mailMessage.Attachments.Add(attachment);
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    smtp.Send(mailMessage);

                    return "Success";
                }
                catch (Exception ex)
                {
                    LogHelper.CreateLog(ex, ErrorType.Exception);
                    return "Error";
                }
                finally
                {
                    mailMessage.Dispose();
                    smtp = null;
                }
            }
            else
            {
                return "Invalid EmailAddress";
            }

        }

        public static async Task<string> SendEmailAsync(string To, string Subject, string BodyText, bool IsSaveEmail = false)
        {
            return await Task.Factory.StartNew(() =>
            {
                if (FValidations.IsValidEmail(To))
                {
                    BodyText = StandardEmail.AddHeaderFooter(BodyText);
                    MailMessage mailMessage = new MailMessage(ConfigurationManager.AppSettings["ADMIN_EMAIL"].ToString(), To, Subject, BodyText);
                    MailAddress Reply = new MailAddress(ConfigurationManager.AppSettings["ADMIN_EMAIL"].ToString(), "relay", System.Text.Encoding.UTF8);
                    mailMessage.ReplyTo = Reply;
                    if (IsSaveEmail)
                    {
                        mailMessage.CC.Add(new MailAddress(ConfigurationManager.AppSettings["ADMIN_EMAIL"].ToString(), "relay", System.Text.Encoding.UTF8));
                    }

                    SmtpClient smtp = new SmtpClient();
                    try
                    {

                        mailMessage.IsBodyHtml = true;
                        ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                        smtp.Send(mailMessage);

                        return "Success";
                    }
                    catch (Exception ex)
                    {
                        LogHelper.CreateLog(ex, ErrorType.Exception);
                        return "Error";
                    }
                    finally
                    {
                        mailMessage.Dispose();
                        smtp = null;
                    }
                }
                else
                {
                    return "Invalid EmailAddress";
                }
            });

        }


        //string _Path = GeneratePdf(HTML, _islandscapemode);

        //var _list = new
        //{
        //    FilePath = _Path
        //};
        //public static string GeneratePdf(string Html, Boolean IsLandscapeMode)
        //{
        //    string data = string.Empty;
        //    try
        //    {
        //        string sitePath = ConfigurationManager.AppSettings["PDF_Path"];
        //        if (!Directory.Exists(sitePath))
        //        {
        //            Directory.CreateDirectory(sitePath);
        //        }
        //        string pdfName = "DRCReport_" + Guid.NewGuid().ToString().Substring(0, 5) + ".pdf";
        //        string pdfPath = sitePath + pdfName;
        //        if (System.IO.File.Exists(pdfPath))
        //        {
        //            System.IO.File.Delete(pdfPath);
        //        }
        //        // Delete all files in a directory    
        //        string[] files = Directory.GetFiles(sitePath);
        //        foreach (string file in files)
        //        {
        //            File.Delete(file);
        //        }
        //        //PdfConverter pdfConverter = GetPDFConverter();
        //        var list = GeneratePdf(Html, pdfPath, IsLandscapeMode, 60);
        //        data = pdfName;
        //        string RootPath = ConfigurationManager.AppSettings["WebPath"];
        //        data = RootPath + "/Content/PDFReports/" + data;
        //    }
        //    catch (Exception ex)
        //    {
        //        LogHelper.CreateLog(ex);
        //        //return Json(ex.Message);
        //    }
        //    return data;

        //}

        //public static string GeneratePdf(string data, string completeFilePath, bool isLandscape, int marginTop = 15, int margin = 15)
        //{
        //    var retFileName = "N/A";
        //    try
        //    {
        //        if (File.Exists(completeFilePath))
        //        {
        //            File.Delete(completeFilePath);
        //        }

        //        //PdfConverter pdfConverter = GetPDFConverter();
        //        EvoPdf.HtmlToPdf.PdfConverter pdfConverter = GetPDFConverter(isLandscape, margin, marginTop);

        //        System.Text.UTF8Encoding encoding = new System.Text.UTF8Encoding();
        //        Byte[] bytes = encoding.GetBytes(data);
        //        System.IO.Stream stream = new System.IO.MemoryStream(bytes);

        //        pdfConverter.SavePdfFromHtmlStreamToFile(stream, encoding, completeFilePath);
        //        retFileName = completeFilePath;

        //    }
        //    catch (Exception ex)
        //    {
        //        LogHelper.CreateLog(ex);
        //        retFileName = "N/A";
        //    }
        //    return retFileName;
        //}

        //public static EvoPdf.HtmlToPdf.PdfConverter GetPDFConverter(bool isLandscape, int margin, int marginTop)
        //{

        //    // get the HTML document width and height in pixels
        //    // default HTML document width is 1024 pixels
        //    int pageWidthPx = 0;
        //    int pageHeightPx = 0;

        //    // set common properties
        //    pageWidthPx = 800;
        //    pageHeightPx = 0;

        //    // create the PDF converter
        //    EvoPdf.HtmlToPdf.PdfConverter pdfConverter = new EvoPdf.HtmlToPdf.PdfConverter(pageWidthPx, pageHeightPx);
        //    try
        //    {
        //        pdfConverter.PdfDocumentOptions.AutoSizePdfPage = true;
        //        pdfConverter.PdfDocumentOptions.PdfCompressionLevel = EvoPdf.HtmlToPdf.PdfCompressionLevel.Normal;
        //        pdfConverter.PdfDocumentOptions.PdfPageOrientation = isLandscape ? PdfPageOrientation.Landscape : PdfPageOrientation.Portrait;
        //        pdfConverter.PdfDocumentOptions.FitWidth = true;
        //        pdfConverter.PdfDocumentOptions.PdfPageSize = EvoPdf.HtmlToPdf.PdfPageSize.A4;
        //        pdfConverter.PdfDocumentOptions.EmbedFonts = true;
        //        pdfConverter.PdfDocumentOptions.LiveUrlsEnabled = false;
        //        pdfConverter.JavaScriptEnabled = true;
        //        pdfConverter.LicenseKey = "2fLr+erq+ejr7+r56vfp+ero9+jr9+Dg4OA=";

        //        pdfConverter.PdfDocumentOptions.CustomPdfPageSize = new SizeF(500, 842);

        //        pdfConverter.PdfDocumentOptions.LeftMargin = margin;
        //        pdfConverter.PdfDocumentOptions.RightMargin = margin;
        //        pdfConverter.PdfDocumentOptions.TopMargin = marginTop;
        //        pdfConverter.PdfDocumentOptions.BottomMargin = margin;
        //        pdfConverter.PdfDocumentOptions.ShowFooter = false;
        //        pdfConverter.PdfDocumentOptions.ShowHeader = false;

        //        float imageXLocation = 0;
        //        float imageyLocation = 0;
        //    }
        //    catch (Exception ex)
        //    {
        //        LogHelper.CreateLog(ex);
        //    }


        //    return pdfConverter;
        //}
    }

    public static class StandardEmail
    {

        public static void SendBackgroundAcceptedEmail(string name, string email, string status)
        {
            string subject = WebConfigurationManager.AppSettings["AppName"] + " - Application Status Update : ";
            string body = "Hello " + name + ", <br/> ";
            body += "We thank you for your patience. <br/></br>";
            body += "We glad to inform you that, after careful consideration, your checkr application has been accepted.<br/></br>";
            body += "<br/>Please go to the NOW Services App to start picking up service requests!</br>";
            //body += status + "<br/></br>";

            //body += "If you have any questions or concerns, please feel free to <a href='mailto:Provider@myProviderlab.com'>contact us.</a><br/><br/>";

            body += "Sincerely,<br/>";
            body += WebConfigurationManager.AppSettings["AppName"] + " Team";
            EmailHelper.SendEmail(email, subject, body);
        }

        public static void SendBackgroundDeniedEmail(string name, string email, string status)
        {
            string subject = WebConfigurationManager.AppSettings["AppName"] + " - Application Status Update : ";
            string body = "Hello " + name + ", <br/> ";
            body += "We thank you for your patience. <br/></br>";
            body += "We regret to inform you that, after careful consideration, your checkr application has been denied.<br/></br>";
            //body += "Your application has been denied for the following reason(s):<br/></br>";
            //body += status + "<br/></br>";

            //body += "If you have any questions or concerns, please feel free to <a href='mailto:Provider@myProviderlab.com'>contact us.</a><br/><br/>";

            body += "Sincerely,<br/>";
            body += WebConfigurationManager.AppSettings["AppName"] + " Team";
            EmailHelper.SendEmail(email, subject, body);
        }

        //Now Emails

        public static void NowEmail(string FromUser, string ToUser, string _ToEmail, string _Subject, string _MoreHtml = "", bool IsSaveEmail = false)
        {
            string html = "<p>Hi " + ToUser + ",</p>";

            //string _ClientLink = "<a href='" + WebConfigurationManager.AppSettings["WebPath"] + "/Admin/Account/Login?ClientID=" +
            //       ClientID.ToString() + "&ProgramID=" + ProgramID.ToString()
            //      + "&ScheduleID=0&Email2=" + Utilities.AesCryptography.EncryptUrl(_ToEmail) + "'>Click here</a>";


            html += _MoreHtml;
            //html += "<p><br>" + FromUser + "'s  has accepted your session </p>";


            html += "<p>Thanks,</p>";
            html += "<p><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelper.SendEmailAsync(_ToEmail, " " + WebConfigurationManager.AppSettings["AppName"] + _Subject, html, IsSaveEmail);

        }

        public static void ProviderStrikeEmail(string reason, string ToUser, string _ToEmail, string _Subject, string _MoreHtml = "")
        {
            string _ProviderHtml = "<p>Dear " + ToUser + ",</p>";


            _ProviderHtml = _ProviderHtml + "<br><p>This is an automatic message from " + WebConfigurationManager.AppSettings["AppName"] + ".</p>";
            _ProviderHtml = _ProviderHtml + "<p>You have been assigned a strike on your account for:</p>";
            _ProviderHtml = _ProviderHtml + "<p>" + reason + "</p>";

            _ProviderHtml = _ProviderHtml + "<p>Please be aware of this strike, as accumulating 3 strikes will result in your account being closed.</p>";
            _ProviderHtml = _ProviderHtml + "<p>We strive to maintain a high level of service to our Clients, and thus we have created this strike system.</p>";

            _ProviderHtml = _ProviderHtml + "<br><p>How to get rid of strikes?</p>";
            _ProviderHtml = _ProviderHtml + "<p>Simply keep using " + WebConfigurationManager.AppSettings["AppName"] + " and avoid getting any more strikes. If you are strike free for 3 months you will have a strike automatically removed.</p>";

            _ProviderHtml = _ProviderHtml + "<br><p>If you think this strike was a mistake, please contact " + WebConfigurationManager.AppSettings["Support_EMAIL"] + " and we will look further into this decision.</p>";


            _ProviderHtml += "<p><br>Thanks,</p>";
            _ProviderHtml += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelper.SendEmailAsync(_ToEmail, " " + WebConfigurationManager.AppSettings["AppName"] + _Subject, _ProviderHtml);

        }

        public static void NowStrikeEmail(string reason, string ToUser, string _ToEmail, string _Subject, string _MoreHtml = "")
        {
            string _AdminHtml = "<p>Dear " + WebConfigurationManager.AppSettings["AppName"] + " Admin,</p>";


            string adminemail = WebConfigurationManager.AppSettings["Support_EMAIL"];


            _AdminHtml = _AdminHtml + "<br><p>This is an automatic message from " + WebConfigurationManager.AppSettings["AppName"] + " alerting that " + ToUser + " has accumulated 3 strikes on his account.</p>";
            _AdminHtml = _AdminHtml + "<p>Please go to " + WebConfigurationManager.AppSettings["AppName"] + " Admin Portal to audit this user and remove access from system if necessary.</p>";

            _AdminHtml += "<p><br>Thanks,</p>";
            _AdminHtml += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelper.SendEmailAsync(_ToEmail, " " + WebConfigurationManager.AppSettings["AppName"] + _Subject, _AdminHtml);

        }


        //End Now

        public static void ScheduleSessionEnd(string FirstName, string _ToEmail, string _ClientName, Int64 ClientID, Int64? ProgramID, string _MoreHtml = "")
        {
            string html = "<p>Hi " + FirstName + ",</p>";

            string _ClientLink = "<a href='" + WebConfigurationManager.AppSettings["WebPath"] + "/Admin/Account/Login?ClientID=" +
                   ClientID.ToString() + "&ProgramID=" + ProgramID.ToString()
                  + "&ScheduleID=0&Email2=" + Utilities.AesCryptography.EncryptUrl(_ToEmail) + "'>Click here</a>";

            //[Client]’s Home-School Daily Report Card (DRC) will end on DATE. If you would like to continue using this DRC, click here [link to Client schedule] to extend the end date. 

            //html += "<p><br>" + _MoreHtml + "</p>";

            //string _MoreHtml = "Schedule for std022’s will end on 10/07/2020. Please change the End Date if you wish to continue monitoring the Clients progress";
            string[] _split = _MoreHtml.Split('.');
            string _EndDate = _split[0].Substring(_split[0].Length - 10);


            html += "<p><br>" + _ClientName + "'s Home-School Daily Report Card (DRC) will end on " + _EndDate + ". If you would like to continue using this DRC, "
                + _ClientLink + " to extend the end date.</p>";


            html += "<p><br>Thanks,</p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelper.SendEmailAsync(_ToEmail, "Your " + WebConfigurationManager.AppSettings["AppName"] + " DRC is ending soon!", html);

        }

        public static void ScheduleSessionEndToday(string FirstName, string _ToEmail, string _ClientName, Int64 ClientID, Int64? ProgramID, string _MoreHtml = "")
        {

            string _ClientLink = "<a href='" + WebConfigurationManager.AppSettings["WebPath"] + "/Admin/Account/Login?ClientID=" +
                  ClientID.ToString() + "&ProgramID=" + ProgramID.ToString()
                 + "&ScheduleID=0&Email2=" + Utilities.AesCryptography.EncryptUrl(_ToEmail) + "'>Click here</a>";

            string _Help = "<a href='" + WebConfigurationManager.AppSettings["LinkToHelp"]
             + "'>Providerial</a>";

            string html = "<p>Hi " + FirstName + ",</p>";

            //[Client]’s Home-School Daily Report Card (DRC) will end today.  If you would like to continue using this DRC, click here [link to Client schedule] to extend the end date. 

            //html += "<p><br>" + _MoreHtml + "</p>";
            html += "<p><br>" + _ClientName + "'s Home-School Daily Report Card (DRC) will end today.  If you would like to continue using this DRC, "
                + _ClientLink + " to extend the end date. </p>";

            html += "<p><br>If you do not choose to extend the end date, you will still be able to access this DRC and goal performance data. To set up a new DRC, visit our " + _Help + " </p>";

            html += "<p><br>Thanks,</p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelper.SendEmailAsync(_ToEmail, "Your " + WebConfigurationManager.AppSettings["AppName"] + " DRC ends today", html);

        }

        public static void ForgetPassword(string _ToUserName, string _Password, string _ToEmail)
        {
            string html = "<p>Hi " + _ToUserName + ",</p>";
            html += "<p><br><br>Thanks for using " + WebConfigurationManager.AppSettings["AppName"] + "!</p>";
            html += "<p><br>Your password is: " + _Password + "</p>";
            html += "<p><br>If you would like to change your password, please go to the profile area of the app.</p>";
            html += "<p><br>Thanks,</p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelper.SendEmailAsync(_ToEmail, WebConfigurationManager.AppSettings["AppName"] + " : Forgot Password", html);

        }

        public static void ResetPassword(string FirstName, string UserId, string _ToEmail)
        {
            string html = "<p>Hi " + FirstName + ",</p>";

            html += "<p><br><br>Please click on the link below to reset your password:</p>";

            html += "<p><br><a href='" + WebConfigurationManager.AppSettings["PasswordResetURL"] + UserId + "'> Reset password </a></p>";
            //html += "<p>" + WebConfigurationManager.AppSettings["PasswordResetURL"] + UserId + "</p>";

            html += "<p><br>This link will expire in two hours.</p>";


            html += "<p><br>Thanks,</p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelper.SendEmailAsync(_ToEmail, "Reset your password for " + WebConfigurationManager.AppSettings["AppName"], html);

        }



        public static void CreatePasswordNewSignup(string FirstName, string UserId, string _ToEmail)
        {
            string html = "<p>Hi " + FirstName + ",</p>";

            html += "<p><br><br>Please click on the link below to reset your password:</p>";

            //html += "<p><br><a href='" + WebConfigurationManager.AppSettings["PasswordResetURL"]+ UserId + "'> Reset password </a></p>";
            html += "<p>" + WebConfigurationManager.AppSettings["PasswordResetURL"] + UserId + "</p>";

            html += "<p><br>This link will expire in two hours.</p>";


            html += "<p><br>Thanks,</p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelper.SendEmailAsync(_ToEmail, "Reset your password for " + WebConfigurationManager.AppSettings["AppName"], html);

        }

        public static void ContactUs(string _ToEmail, string _subject, string _body, string _SendInfor)
        {
            string html = "<p>Hi " + WebConfigurationManager.AppSettings["AppName"] + " Team,</p>";
            html += "<p><br>Feedback!</p>";
            html += "<p><br>" + _body + "</p>";
            html += "<p><br>Thanks,</p>";
            html += "<p><br><strong>Sender: " + _SendInfor + "</strong></p>";

#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed. Consider applying the 'await' operator to the result of the call.
            EmailHelperV1.SendGridEmailAsync(_ToEmail, "Contact Us :" + _subject, html);
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed. Consider applying the 'await' operator to the result of the call.

        }

        public static void PasswordUpdate(string _ToUserName, string _Password, string _ToEmail)
        {

            string html = "<p>Hi " + _ToUserName + ",</p>";
            html += "<p><br>Your password has been changed successfully.</p>";
            html += "<p><br>Thanks,</p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed. Consider applying the 'await' operator to the result of the call.
            EmailHelper.SendEmailAsync(_ToEmail, WebConfigurationManager.AppSettings["AppName"] + " : Password Changed", html);
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed. Consider applying the 'await' operator to the result of the call.

        }

        public static void ForgetPassword_Admin(string _ToUserName, string _Password, string _ToEmail)
        {
            string html = "<p>Hi " + _ToUserName + "</p>";
            html += "<p>Here is the password : " + _Password + "</p>";
            html += "<p><br><br>Thanks for using " + WebConfigurationManager.AppSettings["AppName"] + "<br><strong>" + WebConfigurationManager.AppSettings["AppName"] + " team</strong></p>";


#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed. Consider applying the 'await' operator to the result of the call.
            EmailHelper.SendEmailAsync(_ToEmail, WebConfigurationManager.AppSettings["AppName"] + " : Forgot Password", html);
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed. Consider applying the 'await' operator to the result of the call.

        }

        public static void StoreOrderConfirmation(string _ToUserName, string _OrderNo, string _ToEmail, string _MoreHtml = "")
        {
            string html = "<p>Hi " + _ToUserName + ",</p>";
            html += "<p><br><br>Thanks for using " + WebConfigurationManager.AppSettings["AppName"] + "!</p>";
            html += "<p><br>Your Order No is: " + _OrderNo + "</p>";
            html += "<p><br>" + _MoreHtml + "</p>";
            html += "<p><br>Thanks,</p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

#pragma warning disable CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed. Consider applying the 'await' operator to the result of the call.
            EmailHelper.SendEmailAsync(_ToEmail, WebConfigurationManager.AppSettings["AppName"] + " : Order Confirmation #" + _OrderNo, html);
#pragma warning restore CS4014 // Because this call is not awaited, execution of the current method continues before the call is completed. Consider applying the 'await' operator to the result of the call.

        }

        public static void InviteFrindEmail(string _ToUserName, string _FromUserName, string _ToEmail, string _MoreHtml = "")
        {
            string html = "<p>Hi " + _ToUserName + ",</p>";
            //html += "<p><br><br>Thanks for using " + WebConfigurationManager.AppSettings["AppName"] + "!</p>";
            //html += "<p><br>User : " + _FromUserName + " has send you the invitatino</p>";
            html += "<p><br>" + _MoreHtml + "</p>";
            html += "<p><br>Thanks,</p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelper.SendEmailAsync(_ToEmail, WebConfigurationManager.AppSettings["AppName"] + " : Invitation to join Humminz", html);

        }

        public static void InviteUserEmail(string _ToEmail, string EncrEmail, string Usertype, string InvitedBy)
        {
            string _ClientLink = "<a href='" + WebConfigurationManager.AppSettings["InvitationEmailURL"]
                  + Utilities.AesCryptography.EncryptUrl(_ToEmail) + "'>Click here</a>";

            string _Help = "<a href='" + WebConfigurationManager.AppSettings["LinkToHelp"]
            + "'>home page</a>";

            string html = "<p>Dear " + Usertype + ",</p>";
            // html += "<p><br><br>"+ InvitedBy + " is inviting you to join "+ WebConfigurationManager.AppSettings["AppName"]+", a free home-school communication tool! </p>";
            html += "<p><br><br> A" + Usertype + ", " + InvitedBy + ", is inviting you to join " + WebConfigurationManager.AppSettings["AppName"] + ". </p>";
            //html += "<p><br>User : " + _FromUserName + " has send you the invitatino</p>";
            html += "<p><br>" + _ClientLink + " to create an account.</p>";
            html += "<p><br>To find out what " + WebConfigurationManager.AppSettings["AppName"] + " is all about, visit our " + _Help + " </p>";

            html += "<p><br><br><strong>Thanks for joining,</strong></p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelper.SendEmailAsync(_ToEmail, "You’ve been invited to join " + WebConfigurationManager.AppSettings["AppName"] + "!", html);

        }

        public static void InviteUserEmail_WithoutProgram(string _ToEmail, string EncrEmail, string Usertype, string InvitedBy)
        {
            string _ClientLink = "<a href='" + WebConfigurationManager.AppSettings["InvitationEmailURL"]
                 + Utilities.AesCryptography.EncryptUrl(_ToEmail) + "'>Click here</a>";

            string _Help = "<a href='" + WebConfigurationManager.AppSettings["LinkToHelp"]
            + "'>home page</a>";

            string html = "<p>Dear " + Usertype + ",</p>";
            html += "<p><br><br>" + InvitedBy + " is inviting you to join " + WebConfigurationManager.AppSettings["AppName"] + ", a free home-school communication tool! </p>";

            //html += "<p><br>User : " + _FromUserName + " has send you the invitatino</p>";
            html += "<p><br>" + _ClientLink + " to create an account.</p>";
            html += "<p><br>To find out what " + WebConfigurationManager.AppSettings["AppName"] + " is all about, visit our " + _Help + " </p>";

            html += "<p><br><br><strong>Thanks for joining,</strong></p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelper.SendEmailAsync(_ToEmail, "You’ve been invited to join " + WebConfigurationManager.AppSettings["AppName"] + "!", html);

        }

        public static void InviteUserToJoinProgramEmail(string _ToEmail, string EncrEmail, string Usertype, string InvitedBy,
            Int64? ProgramID, string ProgramName, string _ToFirstName = ""

        )
        {

            string _ClientLink = "<a href='" + WebConfigurationManager.AppSettings["WebPath"] + "/Admin/Account/Login?ClientID=0" +
                   "&ProgramID=" + ProgramID.ToString()
                  + "&ScheduleID=0&Email2=" + Utilities.AesCryptography.EncryptUrl(_ToEmail) + "'>Click here</a>";

            string _Signup = "<a href='" + WebConfigurationManager.AppSettings["InvitationEmailURL"] + EncrEmail
                + "'>Click here</a>";

            string _Help = "<a href='" + WebConfigurationManager.AppSettings["LinkToHelp"]
            + "'>home page</a>";


            string html = "<p>Dear " + Usertype + ",</p>";

            html += "<p><br>" + ProgramName + " is now using MyGoalPal, a free home-school communication tool! </p>";

            html += "<p><br><br>" + InvitedBy + " is inviting you, " + _Signup + " create an account</p>";

            html += "<p><br>To find out what " + WebConfigurationManager.AppSettings["AppName"] + " is all about, visit our " + _Help + " </p>";

            html += "<p><br><br><strong>Thanks for joining,</strong></p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelper.SendEmailAsync(_ToEmail, "You’ve been invited to join " + WebConfigurationManager.AppSettings["AppName"] + "!", html);





        }

        public static void UserToJoinProgramEmail(string _ToEmail, string EncrEmail, string Usertype, string InvitedBy,
           Int64? ProgramID, string ProgramName, string _ToFirstName = ""

       )
        {

            string _ClientLink = "<a href='" + WebConfigurationManager.AppSettings["WebPath"] + "/Admin/Account/Login?ClientID=0" +
                   "&ProgramID=" + ProgramID.ToString()
                  + "&ScheduleID=0&Email2=" + Utilities.AesCryptography.EncryptUrl(_ToEmail) + "'>Click here</a>";

            string _login = "<a href='" + WebConfigurationManager.AppSettings["WebPath"] + "/Admin/Account/Login"
                + "'>Click here</a>";

            string _Help = "<a href='" + WebConfigurationManager.AppSettings["LinkToHelp"]
               + "'>training materials</a>";

            string html = "<p>Dear User,</p>";
            html += "<p><br>Thanks for using " + WebConfigurationManager.AppSettings["AppName"] + ", a free home-school communication tool.</p>";
            if (Usertype == "Researcher")
            {
                html += "<p><br>A " + Usertype + ", " + InvitedBy + ",  is inviting you to join  " + ProgramName.ToUpper() + ", a new Research Program on </p> " + WebConfigurationManager.AppSettings["AppName"] + ".";
            }
            else
            {
                html += "<p><br>A " + Usertype + ", " + InvitedBy + ", is inviting you to join  " + ProgramName.ToUpper() + " on </p> " + WebConfigurationManager.AppSettings["AppName"] + ".";
            }

            html += "<p><br>To make the most of " + WebConfigurationManager.AppSettings["AppName"] + ", check out our " + _Help + " for common questions, trouble-shooting, and more! </p>";


            html += "<p><br><br><strong>Thanks,</strong></p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";


            if (
                Usertype == "ProgramAdmin"
                || Usertype == "Researcher"
                )
            {
                EmailHelper.SendEmailAsync(_ToEmail, "Join a New Research Program on " + WebConfigurationManager.AppSettings["AppName"] + "!", html);
            }
            else
            {
                EmailHelper.SendEmailAsync(_ToEmail, "Join a New School on " + WebConfigurationManager.AppSettings["AppName"] + "!", html);

            }



        }

        public static void IntimateUserForClientLink(string _ToUserName, string _RegNo, string _ToEmail, Int64 ClientID, Int64? ProgramID)
        {
            string html = "<p>Hi " + _ToUserName + ",</p>";

            string _ClientLink = "<a href='" + WebConfigurationManager.AppSettings["WebPath"] + "/Admin/Account/Login?ClientID=" +
                    ClientID.ToString() + "&ProgramID=" + ProgramID.ToString()
                   + "&ScheduleID=0&Email2=" + Utilities.AesCryptography.EncryptUrl(_ToEmail) + "'>Click here</a>";


            html += "<p><br><br>Your " + WebConfigurationManager.AppSettings["AppName"] + " account has been linked with a new Client, " +
                _RegNo + ". " + _ClientLink + " to view or edit the Daily Report Card. </p>";



            html += "<p><br><br><strong>Thanks,</strong></p>";
            html += "<p><br><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";


            EmailHelper.SendEmailAsync(_ToEmail, "You’ve been linked to a new Client!", html);

        }



        public static void VerificationCode(string FirstName, string _ToEmail, string Code)
        {
            //string html = "<p>Hi" + FirstName + ",</p>";         
            string html = "<p>Hi,</p>";
            html += "<p>Please use this code for login:</p>";
            html += "<p><b>Code:</b> " + Code + "</p>";
            //html += "<p>" + WebConfigurationManager.AppSettings["AppPasswordResetURL"] + UserId + "</p>";
            html += "<p>This will expire in two hours.</p>";
            html += "<p>Thanks,</p>";
            html += "<p><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";
            //EmailHelper.SendEmailAsync(_ToEmail, "OTP Verification " + WebConfigurationManager.AppSettings["AppName"], html);
            EmailHelperV1.SendGridEmailAsync(_ToEmail, "OTP Verification " + WebConfigurationManager.AppSettings["AppName"], html);

        }

        public static void AppResetPassword(string FirstName, string UserId, string _ToEmail)
        {
            string html = "<p>Hi " + FirstName + ",</p>";
            html += "<p>Please click on the link below to reset your password:</p>";

            html += "<p><a href='" + WebConfigurationManager.AppSettings["AppPasswordResetURL"] + UserId + "'> Reset password </a></p>";
            //html += "<p>" + WebConfigurationManager.AppSettings["AppPasswordResetURL"] + UserId + "</p>";

            html += "<p>This link will expire in two hours.</p>";


            html += "<p>Thanks,</p>";
            html += "<p><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";

            EmailHelperV1.SendGridEmailAsync(_ToEmail, "Reset your password for " + WebConfigurationManager.AppSettings["AppName"], html);

        }
        public static string AddHeaderFooter(string BodyText)
        {
            var filePath = WebConfigurationManager.AppSettings["EmailTemplatePath"];
            string body = System.IO.File.ReadAllText(filePath);
            body = body.Replace("{{EmailBody}}", BodyText);
            return body;

        }

        public static void JobPickedUpEmail(string FirstName, string _ToEmail, string Jobname, string DriverName)
        {
            //string html = "<p>Hi" + FirstName + ",</p>";         
            string html = "<p>Hi,</p>";
            html += "<p>Your job " + Jobname + " has been picked up by " + DriverName + " </p>";
            html += "<p>Thanks,</p>";
            html += "<p><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";
            //EmailHelper.SendEmailAsync(_ToEmail, "OTP Verification " + WebConfigurationManager.AppSettings["AppName"], html);
            EmailHelperV1.SendGridEmailAsync(_ToEmail, "Job Pickup " + WebConfigurationManager.AppSettings["AppName"], html);

        }

        public static void JobCompletedEmail(string FirstName, string _ToEmail, string Jobname, string DriverName)
        {
            //string html = "<p>Hi" + FirstName + ",</p>";         
            string html = "<p>Hi,</p>";
            html += "<p>Your job " + Jobname + " has been completed by " + DriverName + " </p>";
            html += "<p>Thanks,</p>";
            html += "<p><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";
            //EmailHelper.SendEmailAsync(_ToEmail, "OTP Verification " + WebConfigurationManager.AppSettings["AppName"], html);
            EmailHelperV1.SendGridEmailAsync(_ToEmail, "Job Completed " + WebConfigurationManager.AppSettings["AppName"], html);

        }

        //public static void EmailWithNotification(long EntityId, string FromFullName, string UserType, string Email, string message)
        //{
        //    //string html = "<p>Hi" + FirstName + ",</p>";         
        //    string html = "<p>Hi,</p>";
        //    html += "<p>Please use this code for login:</p>";
        //    html += "<p><b>Code:</b> " + Code + "</p>";
        //    //html += "<p>" + WebConfigurationManager.AppSettings["AppPasswordResetURL"] + UserId + "</p>";
        //    html += "<p>This will expire in two hours.</p>";
        //    html += "<p>Thanks,</p>";
        //    html += "<p><strong>The " + WebConfigurationManager.AppSettings["AppName"] + " Team</strong></p>";
        //    //EmailHelper.SendEmailAsync(_ToEmail, "OTP Verification " + WebConfigurationManager.AppSettings["AppName"], html);
        //    EmailHelperV1.SendGridEmailAsync(_ToEmail, "OTP Verification " + WebConfigurationManager.AppSettings["AppName"], html);

        //}

    }
}
