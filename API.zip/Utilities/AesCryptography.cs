﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace LawyerWatch.Library.Utilities
{
    public static class AesCryptography
    {
        static private ICryptoTransform rijndaelDecryptor;
        static private ICryptoTransform rijndaelEncryptor;
        static private byte[] rawSecretKey = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                              0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};


        public static string EncryptBlowFish(string toEncrypt)
        {
            var settingsReader = new AppSettingsReader();
            var key = (string)settingsReader.GetValue("passwordKey", typeof(String));
            Blowfish blowfish = new Blowfish(key);
            var returnString = blowfish.encryptString(toEncrypt);
            return returnString;
        }
        public static string DecryptBlowFish(string toDecrypt)
        {
            var settingsReader = new AppSettingsReader();
            var key = (string)settingsReader.GetValue("passwordKey", typeof(String));
            var blowfish = new Blowfish(key);
            var returnString = blowfish.decryptString(toDecrypt);
            return returnString;
        }


        static AesCryptography()
        {
            //SecurityKey = "123456789abcdef";
            byte[] passwordKey = EncodeDigest("Sdsol*Dum*-LawyerWatch%^");
            RijndaelManaged rijndael = new RijndaelManaged();
            rijndaelDecryptor = rijndael.CreateDecryptor(passwordKey, rawSecretKey);
            rijndaelEncryptor = rijndael.CreateEncryptor(passwordKey, rawSecretKey);
        }
        static public string Decrypt(string encryptedBase64)
        {
            byte[] encryptedData = Convert.FromBase64String(encryptedBase64);
            byte[] newClearData = new byte[] { 0x20, 0x20, 0x20, 0x20, 0x20, 0x20, 0x20 };
            if (encryptedBase64 != "")
            {
                newClearData = rijndaelDecryptor.TransformFinalBlock(encryptedData, 0, encryptedData.Length);
            }
            return Encoding.ASCII.GetString(newClearData);
        }
        static private byte[] EncodeDigest(string text)
        {
            MD5CryptoServiceProvider x = new MD5CryptoServiceProvider();
            byte[] data = Encoding.ASCII.GetBytes(text);
            return x.ComputeHash(data);
        }
        static public string Encrypt(string plainText)
        {
            var obj = Encoding.ASCII.GetBytes(plainText);
            byte[] newClearData = rijndaelEncryptor.TransformFinalBlock(obj, 0, obj.Length);
            return Convert.ToBase64String(newClearData);
        }



        //Usage
        //--var encryptedEmail = HttpUtility.UrlEncode(AesCryptography.EncryptUrl(user.PrimaryEmail));
        //--var encryptedDocid = HttpUtility.UrlEncode(AesCryptography.EncryptUrl(Convert.ToString(doc.DocumentID)));
        //--html = html.Replace(DefaultEmailTemplate.ButtonLink, webPath + "/Client/home?uid=" + encryptedEmail + "&fid=" + encryptedDocid);

        //--ViewBag.Uid = AesCryptography.DecryptUrl(HttpUtility.UrlDecode(uid));
        //--ViewBag.Fid = AesCryptography.DecryptUrl(HttpUtility.UrlDecode(fid));

        public static string EncryptUrl(string clearText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }


        public static string DecryptUrl(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            cipherText = cipherText.Replace(" ", "+");
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }


    }
}
