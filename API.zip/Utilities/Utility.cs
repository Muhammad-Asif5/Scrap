﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LawyerWatch.Library.Utilities
{
    public class Utility
    {
        //public static List<string> ExceptionMessages = new List<string>() {"Already exist user with this email address.", "Provided email address not exist in our record.", "Invalid password.","No data was found.","Same address already exist for this user." ,"You just allow to pass maximum three cities.", "Already exist user with this phone number.","Invalid device type" };
        public static string ExistEmail = "Already exist user with this email address.";
        public static string NoExistEmail = "Provided email address not exist in our record.";
        public static string InvalidPassword = "Invalid password.";
        public static string NoFound = "No data was found.";
        public static string ExistAddress = "Same address already exist for this user.";
        public static string ExceedCity = "You just allow to pass maximum three cities.";
        public static string ExistPhonNo = "Already exist user with this phone number.";
        public static string InvalidDevice = "Invalid device type";
        public static string ServerError = "Internal server error.";
        public static string LogoutOther = "Log Out From Other Account.";
        public static string InactiveUser = "The user account is not active.";
        public static string NoALlow = "You are not allow to access.";


        public enum UserType
        {
            Driver,
            Advertiser,
            Advertiser_Editor,
            Super_Admin,
            Admin
        }
        public enum RecordStatus
        {
            Active,
            Deleted,
            Approved,
            Pending
        }
        public enum DeviceType
        {
            IOS,
            Android
        }
    }
}
