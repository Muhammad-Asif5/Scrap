﻿using LawyerWatch.Library.Utilities;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace LawyerWatch.Library.API
{
    public class JsonResponse
    {
        public static ApiResponse GetResponse(ResponseCode responseMessage, object data, string KeyName = "Message", string responseMsg = "")
        {
            ApiResponse response = new ApiResponse();
            response.Response = new Dictionary<string, object>();

            Dictionary<string, object> _MyResponse = new Dictionary<string, object>();

            //Type _type = data.GetType();

            //var _st = t.IsSerializable;
            //if (t.Equals(typeof(string)))
            //{
            //    var _e = 2;
            //}

            response.Response.Add("Code", Numerics.GetInt(responseMessage));

            switch (responseMessage)
            {
                case ResponseCode.Success:
                    if (data != null)
                    {
                        response.Response.Add("Status", data.GetType().Equals(typeof(string)) ? data : responseMsg);
                    }
                    else
                    {
                        response.Response.Add("Status", responseMsg);
                    }
                    break;

                case ResponseCode.Failure:
                    response.Response.Add("Status", responseMsg);
                    break;

                case ResponseCode.Expired:
                    response.Response.Add("Status", responseMsg);
                    break;

                case ResponseCode.Unauthorized:
                    response.Response.Add("Status", responseMsg);
                    break;
                //case ResponseCode.BadRequest:
                //    response.Response.Add("Message", " The request is invalid.");
                //    response.Response.Add("ModelState", data);
                //    break;

                case ResponseCode.Exception:
                    response.Response.Add("Status", "Exception: " + responseMsg);
                    break;

                case ResponseCode.Info:
                    if (responseMsg != null)
                    {
                        responseMsg = responseMsg.Replace("**Sql**", "");
                    }

                    if (data.GetType().Equals(typeof(string)))
                    {
                        data = data.ToString().Replace("**Sql**", "");
                    }

                    if (data != null)
                    {
                        response.Response.Add("Status", data.GetType().Equals(typeof(string)) ? data : responseMsg);
                    }
                    else
                    {
                        response.Response.Add("Status", responseMsg);
                    }
                    break;
            }

            //_MyResponse.Add(KeyName, data);
            //response.Response.Add("DataObject", _MyResponse);

            if (responseMessage == ResponseCode.Success)
            {
                if (data != null && data.GetType().Equals(typeof(string)))
                {
                    //_MyResponse.Add(KeyName, data);
                    response.Response.Add("DataObject", _MyResponse);
                }
                else
                {
                    if (data != null)
                    {
                        _MyResponse.Add(KeyName, data);
                        response.Response.Add("DataObject", _MyResponse);
                    }
                    else
                    {
                        response.Response.Add("DataObject", _MyResponse);
                    }
                }
            }
            else
            {
                response.Response.Add("DataObject", new Dictionary<string, object>());
            }

            return response;
        }

        public static ApiResponse GetResponseDynamic(ResponseCode responseMessage, object data, string KeyName = "Message", string responseMsg = "", params dynamic[] _param)
        {
            ApiResponse response = new ApiResponse();
            response.Response = new Dictionary<string, object>();
            Dictionary<string, object> _MyResponse = new Dictionary<string, object>();
            Dictionary<string, object> _DynamicParam = new Dictionary<string, object>();
            //  Type _type = data.GetType();

            response.Response.Add("Code", Numerics.GetInt(responseMessage));

            switch (responseMessage)
            {
                case ResponseCode.Success:
                    if (data != null)
                    {
                        response.Response.Add("Status", data.GetType().Equals(typeof(string)) ? data : responseMsg);
                    }
                    else
                    {
                        response.Response.Add("Status", responseMsg);
                    }


                    break;
                case ResponseCode.Failure:
                    response.Response.Add("Status", responseMsg);
                    break;
                case ResponseCode.Expired:
                    response.Response.Add("Status", responseMsg);
                    break;
                case ResponseCode.Unauthorized:
                    response.Response.Add("Status", responseMsg);
                    break;
                //case ResponseCode.BadRequest:
                //    response.Response.Add("Message", " The request is invalid.");
                //    response.Response.Add("ModelState", data);
                //    break;

                case ResponseCode.Exception:
                    response.Response.Add("Status", "Exception: " + responseMsg);
                    break;
                case ResponseCode.Info:
                    if (data != null)
                    {
                        response.Response.Add("Status", data.GetType().Equals(typeof(string)) ? data : responseMsg);
                    }
                    else
                    {
                        response.Response.Add("Status", responseMsg);
                    }
                    break;
            }

            if (responseMessage == ResponseCode.Success && data != null)
            {
                int _count = 1;

                foreach (dynamic str in _param)
                {
                    foreach (KeyValuePair<string, object> _pair in str)
                    {
                        _DynamicParam.Add(_pair.Key, _pair.Value);
                    }
                    _count = _count + 1;
                }
                _DynamicParam.Add("Listing", data);

                _MyResponse.Add(KeyName, _DynamicParam);

                response.Response.Add("DataObject", _MyResponse);
            }
            else
            {
                //_MyResponse.Add(KeyName, data);
                //response.Response.Add("DataObject", _MyResponse);
                response.Response.Add("DataObject", new Dictionary<string, object>());
            }


            return response;
        }

        /// <summary>
        ///  return Request.CreateResponse(HttpStatusCode.OK,
        //JsonResponse.GetResponseDynamic3(ResponseCode.Success,
        //   _object, "FeedPostsList", "",
        //          _V2Gen.Object2, _V2Gen.Object3
        //          ));
        /// </summary>
        /// <param name="responseMessage"></param>
        /// <param name="data"></param>
        /// <param name="KeyName"></param>
        /// <param name="responseMsg"></param>
        /// <param name="_param"></param>
        /// <returns></returns>
        public static ApiResponse GetResponseDynamic_MultiDic(ResponseCode responseMessage, object data, string KeyName = "Message", string responseMsg = "", params dynamic[] _param)
        {
            ApiResponse response = new ApiResponse();
            response.Response = new Dictionary<string, object>();

            Dictionary<string, object> _MainResponse = new Dictionary<string, object>();
            Dictionary<string, object> _MyResponse = new Dictionary<string, object>();
            Dictionary<string, object> _DynamicParam = new Dictionary<string, object>();
            //  Type _type = data.GetType();

            response.Response.Add("Code", Numerics.GetInt(responseMessage));

            switch (responseMessage)
            {
                case ResponseCode.Success:
                    if (data != null)
                    {
                        response.Response.Add("Status", data.GetType().Equals(typeof(string)) ? data : responseMsg);
                    }
                    else
                    {
                        response.Response.Add("Status", responseMsg);
                    }

                    break;

                case ResponseCode.Failure:
                    response.Response.Add("Status", responseMsg);
                    break;

                case ResponseCode.Expired:
                    response.Response.Add("Status", responseMsg);
                    break;

                case ResponseCode.Unauthorized:
                    response.Response.Add("Status", responseMsg);
                    break;
                //case ResponseCode.BadRequest:
                //    response.Response.Add("Message", " The request is invalid.");
                //    response.Response.Add("ModelState", data);
                //    break;

                case ResponseCode.Exception:
                    response.Response.Add("Status", "Exception: " + responseMsg);
                    break;

                case ResponseCode.Info:
                    if (data != null)
                    {
                        response.Response.Add("Status", data.GetType().Equals(typeof(string)) ? data : responseMsg);
                    }
                    else
                    {
                        response.Response.Add("Status", responseMsg);
                    }
                    break;
            }

            if (responseMessage == ResponseCode.Success && data != null)
            {
                int _count = 0;
                string _header = "";

                foreach (dynamic str in _param)
                {
                    _count = 1;
                    _DynamicParam = new Dictionary<string, object>();

                    foreach (KeyValuePair<string, dynamic> _pair in str)
                    {
                        //get header
                        if (_count == 1)
                        {
                            _count = 0;
                            _header = _pair.Key;
                            continue;
                        }

                        _DynamicParam.Add(_pair.Key, _pair.Value);
                    }

                    _MyResponse.Add(_header, _DynamicParam);
                }

                _MyResponse.Add("Listing", data);
                _MainResponse.Add(KeyName, _MyResponse);
                response.Response.Add("DataObject", _MainResponse);
            }
            else
            {
                //_MyResponse.Add(KeyName, data);
                //response.Response.Add("DataObject", _MyResponse);
                response.Response.Add("DataObject", new Dictionary<string, object>());
            }

            return response;
        }

        public static ApiResponse GetResponseDynamicMultiObject(ResponseCode responseMessage, object data, string KeyName = "Message", string responseMsg = "", params dynamic[] _param)
        {
            ApiResponse response = new ApiResponse();
            response.Response = new Dictionary<string, object>();

            Dictionary<string, object> _MainResponse = new Dictionary<string, object>();
            Dictionary<string, object> _MyResponse = new Dictionary<string, object>();
            Dictionary<string, object> _DynamicParam = new Dictionary<string, object>();
            //  Type _type = data.GetType();

            response.Response.Add("Code", Numerics.GetInt(responseMessage));

            switch (responseMessage)
            {
                case ResponseCode.Success:
                    if (data != null)
                    {
                        response.Response.Add("Status", data.GetType().Equals(typeof(string)) ? data : responseMsg);
                    }
                    else
                    {
                        response.Response.Add("Status", responseMsg);
                    }

                    break;

                case ResponseCode.Failure:
                    response.Response.Add("Status", responseMsg);
                    break;

                case ResponseCode.Expired:
                    response.Response.Add("Status", responseMsg);
                    break;

                case ResponseCode.Unauthorized:
                    response.Response.Add("Status", responseMsg);
                    break;
                //case ResponseCode.BadRequest:
                //    response.Response.Add("Message", " The request is invalid.");
                //    response.Response.Add("ModelState", data);
                //    break;

                case ResponseCode.Exception:
                    response.Response.Add("Status", "Exception: " + responseMsg);
                    break;

                case ResponseCode.Info:
                    if (data != null)
                    {
                        response.Response.Add("Status", data.GetType().Equals(typeof(string)) ? data : responseMsg);
                    }
                    else
                    {
                        response.Response.Add("Status", responseMsg);
                    }
                    break;
            }

            if (responseMessage == ResponseCode.Success && data != null)
            {
                int _count = 0;
                string _header = "";

                foreach (dynamic str in _param)
                {
                    _count = 1;
                    _DynamicParam = new Dictionary<string, object>();

                    foreach (KeyValuePair<string, dynamic> _pair in str)
                    {
                        // get header
                        if (_count == 1)
                        {
                            _count = 0;
                            _header = _pair.Key;
                            continue;
                        }

                        _DynamicParam.Add(_pair.Key, _pair.Value);
                    }

                    //_MyResponse.Add(_header, _DynamicParam);
                }

                // _MyResponse.Add("Listing", data);

                _MainResponse.Add(KeyName, data);
                _MainResponse.Add(_header, _DynamicParam);
                response.Response.Add("DataObject", _MainResponse);
            }
            else
            {
                //_MyResponse.Add(KeyName, data);
                //response.Response.Add("DataObject", _MyResponse);
                response.Response.Add("DataObject", new Dictionary<string, object>());
            }

            return response;
        }


        public static ApiResponse GetResponseModel(ResponseCode responseMessage, dynamic data, string KeyName = "Message")
        {
            ApiResponse response = new ApiResponse();
            response.Response = new Dictionary<string, object>();
            response.Response.Add("Code", Numerics.GetInt(responseMessage));

            string _errors = "";
            foreach (var state in data)
            {
                foreach (var error in state.Value.Errors)
                {
                    if (error.ErrorMessage != "")
                    {
                        _errors = _errors + error.ErrorMessage + " \n ";
                    }

                    if (error.Exception != null && error.Exception.Message != "")
                    {
                        if (error.Exception.Message.ToString().Contains("Required property"))
                        {
                            string _MyMessage = error.Exception.Message.ToString().Substring(0, error.Exception.Message.ToString().IndexOf(",")).Replace("Required property '", "The ").Replace("' not found in JSON. Path ''", " field is required.");
                            _errors = _errors + _MyMessage + " \n ";
                        }
                        else
                        {
                            _errors = _errors + error.Exception.Message + " \n ";
                        }
                    }
                }
            }

            switch (responseMessage)
            {
                case ResponseCode.Success:
                    response.Response.Add("Status", "Success");
                    break;

                case ResponseCode.Failure:
                    response.Response.Add("Status", _errors);
                    break;

                case ResponseCode.Expired:
                    response.Response.Add("Status", _errors);
                    break;

                case ResponseCode.Unauthorized:
                    response.Response.Add("Status", "Unauthorized");
                    break;
                //case ResponseCode.BadRequest:
                //    response.Response.Add("Message", " The request is invalid.");
                //    response.Response.Add("ModelState", data);
                //    break;

                case ResponseCode.Exception:
                    response.Response.Add("Status", "Exception: " + data);
                    break;

                case ResponseCode.Info:
                    response.Response.Add("Status", _errors);
                    response.Response.Add("DataObject", new Dictionary<string, object>());
                    break;
            }

            if (responseMessage == ResponseCode.Success && data != null)
            {
                response.Response.Add(KeyName, data);
            }
            return response;
        }

        public static string GetResponseString(ResponseCode responseMessage)
        {
            return JsonConvert.SerializeObject(GetResponse(ResponseCode.Unauthorized, null));
        }
    }

    public class ApiResponse
    {
        public Dictionary<string, object> Response { get; set; }
    }

    public enum ResponseCode
    {
        Success,
        Failure,
        Unauthorized,
        Exception,
        Info,
        Expired
    }
}
