﻿
using LawyerWatch.Library.Utilities;
using SendGrid;
using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Configuration;


namespace Now.Library.Utilities
{


    public static class MultipartFiles
    {
        //string _FolderPath = "Messageimages" + @"\" + _MessageID;
        // string _FolderSite = "Messageimages" + "/" + _MessageID;

        // var imgResponse = MultipartFiles.GetMultipartImage(HttpContext.Current.Request.Files, "Image", _FolderPath, _imagethumbsize, _imagethumbsize, _imageSize, _imageSize, true, true, true, _FolderSite);


        //Usage 
        //var imgResponse = MultipartFiles.GetMultipartImage(HttpContext.Current.Request.Files, "Image", "Profileimage", _imagethumbsize, _imagethumbsize, _imageSize, _imageSize, "Profileimage");
        //        // Check whether the image file is created successfully
        //        if (!imgResponse.IsSuccess)
        //        {
        //            return Request.CreateResponse(HttpStatusCode.OK,
        //                JsonResponse.GetResponse(ResponseCode.Info, imgResponse.ResponseMessage));
        //        }



        public static ImageResponse GetMultipartImage2(
                                HttpFileCollection files, string fileKey, string folderPath,
                                int thumbWidth, int thumbHeight,
                                int thumbWidth2, int thumbHeight2,
                                int imgWidth, int imgHeight,
                                string folderPathSite,
                                bool deleteOriginal = false, bool GenThumbnail = true,
                                bool GenThumbnail2 = true,
                                bool GenImage = true, bool GenBanner = false)
        {

            try
            {
                string _SiteRoot = WebConfigurationManager.AppSettings["SiteImgPath"];
                string _SiteURL = WebConfigurationManager.AppSettings["SiteImgURL"];


                var file = files.Count > 0 ? files[fileKey] : null;
                if (file == null)
                {
                    file = files.Count > 0 ? files[0] : null;
                }
                ImageResponse response = new ImageResponse();

                if (file != null && file.ContentLength > 0)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    string extension = Path.GetExtension(file.FileName).ToLower();
                    string[] arr = new string[] { ".png", ".jpg", ".jpeg", ".gif", ".bmp" };

                    if (arr.Contains(extension))
                    {
                        string _NewFileName = Guid.NewGuid() + extension;

                        string tempfilePath = _SiteRoot + @"\" + "TempImages" + @"\" + _NewFileName;
                        Helper.CreateDirectories(_SiteRoot + @"\" + "TempImages" + @"\");

                        string newFilePath = _SiteRoot + @"\" + folderPath + @"\";
                        Helper.CreateDirectories(_SiteRoot + @"\" + folderPath + @"\");


                        string strIamgeURLfordb = _SiteURL + "/" + folderPathSite + "/" + _NewFileName;

                        file.SaveAs(tempfilePath);
                        string thumbnailresizename = "";
                        string thumbnailresizename2 = "";
                        string Imageresizename = "";
                        string ImageBannerresizename = "";
                        string imageresizenametmp = "";

                        if (GenThumbnail == true)
                        {
                            thumbnailresizename = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "_T_" + _NewFileName, thumbWidth, thumbHeight);
                        }

                        if (GenThumbnail2 == true)
                        {
                            thumbnailresizename2 = ResizeImage.Resize_Image_Thumb_fixed(tempfilePath, newFilePath, "_T2_" + _NewFileName, thumbWidth2, thumbHeight2);
                        }

                        if (GenImage == true)
                        {
                            //Scale up the image 
                            //imageresizenametmp = ResizeImage.ScaleImage(tempfilePath, tempfilePath, "_S_" + _NewFileName, 650, 650);

                            Imageresizename = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "_A_" + _NewFileName, imgWidth, imgHeight);
                            //Imageresizename = ResizeImage.CropImage(tempfilePath , newFilePath, "_A_" + imageresizenametmp, 0, 50, 640, 360);
                        }

                        if (GenBanner == true)
                        {
                            //Banner Image (event listing)
                            ImageBannerresizename = ResizeImage.CropImage(tempfilePath, newFilePath, "_B_" + imageresizenametmp, 0, 100, 640, 270);
                        }


                        if (deleteOriginal == true)
                        {
                            if (File.Exists(tempfilePath))
                            {
                                File.Delete(tempfilePath);
                            }
                        }

                        response.ThumbnailURL2 = _SiteURL + "/" + folderPathSite + "/" + thumbnailresizename2;
                        response.ThumbnailURL = _SiteURL + "/" + folderPathSite + "/" + thumbnailresizename;
                        response.ImageURL = _SiteURL + "/" + folderPathSite + "/" + Imageresizename;

                        response.BannerImage_URL = _SiteURL + "/" + folderPathSite + "/" + ImageBannerresizename;
                        response.IsSuccess = true;
                        response.ResponseMessage = "";

                        return response;
                    }
                    else
                    {
                        response.IsSuccess = false;
                        response.ResponseMessage = "File Extension not supported";

                        return response;
                    }
                }
                else
                {
                    response.IsSuccess = false;
                    response.ResponseMessage = "File Not found";

                    return response;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);

            }



        }


        public static ImageResponse GetMultipartImage2(
                                 HttpFileCollectionBase files, string fileKey, string folderPath,
                                 int thumbWidth, int thumbHeight,
                                 int thumbWidth2, int thumbHeight2,
                                 int imgWidth, int imgHeight,
                                 string folderPathSite,
                                 bool deleteOriginal = false, bool GenThumbnail = true,
                                 bool GenImage = true, bool GenBanner = false)
        {

            string _SiteRoot = WebConfigurationManager.AppSettings["SiteImgPath"];
            string _SiteURL = WebConfigurationManager.AppSettings["SiteImgURL"];


            var file = files.Count > 0 ? files[fileKey] : null;
            ImageResponse response = new ImageResponse();

            if (file != null && file.ContentLength > 0)
            {
                var fileName = Path.GetFileName(file.FileName);
                string extension = Path.GetExtension(file.FileName).ToLower();
                string[] arr = new string[] { ".png", ".jpg", ".jpeg", ".gif", ".bmp" };

                if (arr.Contains(extension))
                {
                    string _NewFileName = Guid.NewGuid() + extension;

                    string tempfilePath = _SiteRoot + @"\" + "TempImages" + @"\" + _NewFileName;
                    Helper.CreateDirectories(_SiteRoot + @"\" + "TempImages" + @"\");

                    string newFilePath = _SiteRoot + @"\" + folderPath + @"\";
                    Helper.CreateDirectories(_SiteRoot + @"\" + folderPath + @"\");


                    string strIamgeURLfordb = _SiteURL + "/" + folderPathSite + "/" + _NewFileName;

                    file.SaveAs(tempfilePath);
                    string thumbnailresizename = "";
                    string thumbnailresizename2 = "";
                    string Imageresizename = "";
                    string ImageBannerresizename = "";
                    string imageresizenametmp = "";

                    if (GenThumbnail == true)
                    {
                        thumbnailresizename = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "_T_" + _NewFileName, thumbWidth, thumbHeight);
                        thumbnailresizename2 = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "_T2_" + _NewFileName, thumbWidth2, thumbHeight2);
                    }

                    if (GenImage == true)
                    {
                        //Scale up the image 
                        //imageresizenametmp = ResizeImage.ScaleImage(tempfilePath, tempfilePath, "_S_" + _NewFileName, 650, 650);

                        Imageresizename = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "_A_" + _NewFileName, imgWidth, imgHeight);
                        //Imageresizename = ResizeImage.CropImage(tempfilePath , newFilePath, "_A_" + imageresizenametmp, 0, 50, 640, 360);
                    }

                    if (GenBanner == true)
                    {
                        //Banner Image (event listing)
                        ImageBannerresizename = ResizeImage.CropImage(tempfilePath, newFilePath, "_B_" + imageresizenametmp, 0, 100, 640, 270);
                    }


                    if (deleteOriginal == true)
                    {
                        if (File.Exists(tempfilePath))
                        {
                            File.Delete(tempfilePath);
                        }
                    }

                    response.ThumbnailURL2 = _SiteURL + "/" + folderPathSite + "/" + thumbnailresizename2;
                    response.ThumbnailURL = _SiteURL + "/" + folderPathSite + "/" + thumbnailresizename;
                    response.ImageURL = _SiteURL + "/" + folderPathSite + "/" + Imageresizename;
                    response.BannerImage_URL = _SiteURL + "/" + folderPathSite + "/" + ImageBannerresizename;
                    response.IsSuccess = true;
                    response.ResponseMessage = "";

                    return response;
                }
                else
                {
                    response.IsSuccess = false;
                    response.ResponseMessage = "File Extension not supported";

                    return response;
                }
            }
            else
            {
                response.IsSuccess = false;
                response.ResponseMessage = "File Not found";

                return response;
            }



        }



        public static ImageResponse GetMultipartImage(
                                    HttpFileCollection files, string fileKey, string folderPath,
                                    int thumbWidth, int thumbHeight,
                                    int imgWidth, int imgHeight,
                                    string folderPathSite,
                                    bool deleteOriginal = false, bool GenThumbnail = true,
                                    bool GenImage = true, bool GenBanner = false)
        {

            string _SiteRoot = WebConfigurationManager.AppSettings["SiteImgPath"];
            string _SiteURL = WebConfigurationManager.AppSettings["SiteImgURL"];


            var file = files.Count > 0 ? files[fileKey] : null;
            if (file == null)
            {
                file = files.Count > 0 ? files[0] : null;
            }
            ImageResponse response = new ImageResponse();

            if (file != null && file.ContentLength > 0)
            {
                var fileName = Path.GetFileName(file.FileName);
                string extension = Path.GetExtension(file.FileName).ToLower();
                string[] arr = new string[] { ".png", ".jpg", ".jpeg", ".gif", ".bmp" };

                if (arr.Contains(extension))
                {
                    string _NewFileName = Guid.NewGuid() + extension;

                    string tempfilePath = _SiteRoot + @"\" + "TempImages" + @"\" + _NewFileName;
                    Helper.CreateDirectories(_SiteRoot + @"\" + "TempImages" + @"\");

                    string newFilePath = _SiteRoot + @"\" + folderPath + @"\";
                    Helper.CreateDirectories(_SiteRoot + @"\" + folderPath + @"\");


                    string strIamgeURLfordb = _SiteURL + "/" + folderPathSite + "/" + _NewFileName;
                    //Content/Upload/FeedMedia/2023/8/ac8a1855-a041-414f-bedb-ba4a076c12f7.jpg

                    file.SaveAs(newFilePath+ _NewFileName);
                    string thumbnailresizename = "";
                    string Imageresizename = "";
                    string ImageBannerresizename = "";
                    string imageresizenametmp = "";

                    if (GenThumbnail == true)
                    {
                        thumbnailresizename = ResizeImage.Resize_Image_Thumb(newFilePath + _NewFileName, newFilePath, "_T_" + _NewFileName, thumbWidth, thumbHeight);
                    }

                    if (deleteOriginal == true)
                    {
                        if (File.Exists(newFilePath + _NewFileName))
                        {
                            File.Delete(newFilePath + _NewFileName);
                        }
                    }


                    response.ThumbnailURL = _SiteURL + "/" + folderPathSite + "/" + thumbnailresizename;
                    response.ImageURL = _SiteURL + "/" + folderPathSite + "/" + Imageresizename;
                    response.BannerImage_URL = _SiteURL + "/" + folderPathSite + "/" + ImageBannerresizename;
                    response.IsSuccess = true;
                    response.ResponseMessage = "";

                    return response;
                }
                else
                {
                    response.IsSuccess = false;
                    response.ResponseMessage = "File Extension not supported";

                    return response;
                }
            }
            else
            {
                response.IsSuccess = false;
                response.ResponseMessage = "File Not found";

                return response;
            }



        }



        public static ImageResponse GetMultipartImage_transparent(
                                  HttpFileCollection files, string fileKey, string folderPath,
                                  int thumbWidth, int thumbHeight,
                                  int imgWidth, int imgHeight,
                                  string folderPathSite,
                                  bool deleteOriginal = false, bool GenThumbnail = true,
                                  bool GenImage = true, bool GenBanner = false)
        {

            string _SiteRoot = WebConfigurationManager.AppSettings["SiteImgPath"];
            string _SiteURL = WebConfigurationManager.AppSettings["SiteImgURL"];


            var file = files.Count > 0 ? files[fileKey] : null;
            if (file == null)
            {
                file = files.Count > 0 ? files[0] : null;
            }
            ImageResponse response = new ImageResponse();

            if (file != null && file.ContentLength > 0)
            {
                var fileName = Path.GetFileName(file.FileName);
                string extension = Path.GetExtension(file.FileName).ToLower();
                string[] arr = new string[] { ".png", ".jpg", ".jpeg", ".gif", ".bmp" };

                if (arr.Contains(extension))
                {
                    string _NewFileName = Guid.NewGuid() + extension;

                    string tempfilePath = _SiteRoot + @"\" + "TempImages" + @"\" + _NewFileName;
                    Helper.CreateDirectories(_SiteRoot + @"\" + "TempImages" + @"\");

                    string newFilePath = _SiteRoot + @"\" + folderPath + @"\";
                    Helper.CreateDirectories(_SiteRoot + @"\" + folderPath + @"\");


                    string strIamgeURLfordb = _SiteURL + "/" + folderPathSite + "/" + _NewFileName;

                    file.SaveAs(tempfilePath);
                    string thumbnailresizename = "";
                    string Imageresizename = "";
                    string ImageBannerresizename = "";
                    string imageresizenametmp = "";

                    if (GenThumbnail == true)
                    {
                        thumbnailresizename = ResizeImage.Resize_Image_Thumb_Transparent(tempfilePath, newFilePath, "_T_" + _NewFileName, thumbWidth, thumbHeight);
                    }

                    if (GenImage == true)
                    {
                        //Scale up the image 
                        //imageresizenametmp = ResizeImage.ScaleImage(tempfilePath, tempfilePath, "_S_" + _NewFileName, 650, 650);

                        Imageresizename = ResizeImage.Resize_Image_Thumb_Transparent(tempfilePath, newFilePath, "_TT_" + _NewFileName, imgWidth, imgHeight);
                        //Imageresizename = ResizeImage.CropImage(tempfilePath , newFilePath, "_A_" + imageresizenametmp, 0, 50, 640, 360);
                    }

                    if (GenBanner == true)
                    {
                        //Banner Image (event listing)
                        ImageBannerresizename = ResizeImage.CropImage(tempfilePath, newFilePath, "_B_" + imageresizenametmp, 0, 100, 640, 270);
                    }


                    if (deleteOriginal == true)
                    {
                        if (File.Exists(tempfilePath))
                        {
                            File.Delete(tempfilePath);
                        }
                    }


                    response.ThumbnailURL = _SiteURL + "/" + folderPathSite + "/" + thumbnailresizename;
                    response.ImageURL = _SiteURL + "/" + folderPathSite + "/" + Imageresizename;
                    response.BannerImage_URL = _SiteURL + "/" + folderPathSite + "/" + ImageBannerresizename;
                    response.IsSuccess = true;
                    response.ResponseMessage = "";

                    return response;
                }
                else
                {
                    response.IsSuccess = false;
                    response.ResponseMessage = "File Extension not supported";

                    return response;
                }
            }
            else
            {
                response.IsSuccess = false;
                response.ResponseMessage = "File Not found";

                return response;
            }



        }



        public static ImageResponse GetMultipartImagePosted(
                                  HttpPostedFileBase file, string fileKey, string folderPath,
                                  int thumbWidth, int thumbHeight,
                                  int imgWidth, int imgHeight,
                                  string folderPathSite,
                                  bool deleteOriginal = false, bool GenThumbnail = true,
                                  bool GenImage = true, bool GenBanner = false)
        {

            string _SiteRoot = WebConfigurationManager.AppSettings["SiteImgPath"];
            string _SiteURL = WebConfigurationManager.AppSettings["SiteImgURL"];


            ImageResponse response = new ImageResponse();

            if (file != null && file.ContentLength > 0)
            {
                var fileName = Path.GetFileName(file.FileName);
                string extension = Path.GetExtension(file.FileName).ToLower();
                string[] arr = new string[] { ".png", ".jpg", ".jpeg", ".gif", ".bmp" };

                if (arr.Contains(extension))
                {
                    string _NewFileName = Guid.NewGuid() + extension;

                    string tempfilePath = _SiteRoot + @"\" + "TempImages" + @"\" + _NewFileName;
                    Helper.CreateDirectories(_SiteRoot + @"\" + "TempImages" + @"\");

                    string newFilePath = _SiteRoot + @"\" + folderPath + @"\";
                    Helper.CreateDirectories(_SiteRoot + @"\" + folderPath + @"\");


                    string strIamgeURLfordb = _SiteURL + "/" + folderPathSite + "/" + _NewFileName;

                    file.SaveAs(tempfilePath);
                    string thumbnailresizename = "";
                    string Imageresizename = "";
                    string ImageBannerresizename = "";
                    string imageresizenametmp = "";

                    if (GenThumbnail == true)
                    {
                        thumbnailresizename = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "_T_" + _NewFileName, thumbWidth, thumbHeight);
                    }

                    if (GenImage == true)
                    {
                        //Scale up the image 
                        //imageresizenametmp = ResizeImage.ScaleImage(tempfilePath, tempfilePath, "_S_" + _NewFileName, 650, 650);

                        Imageresizename = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "_A_" + _NewFileName, imgWidth, imgHeight);
                        //Imageresizename = ResizeImage.CropImage(tempfilePath , newFilePath, "_A_" + imageresizenametmp, 0, 50, 640, 360);
                    }

                    if (GenBanner == true)
                    {
                        //Banner Image (event listing)
                        ImageBannerresizename = ResizeImage.CropImage(tempfilePath, newFilePath, "_B_" + imageresizenametmp, 0, 100, 640, 270);
                    }


                    if (deleteOriginal == true)
                    {
                        if (File.Exists(tempfilePath))
                        {
                            File.Delete(tempfilePath);
                        }
                    }


                    response.ThumbnailURL = _SiteURL + "/" + folderPathSite + "/" + thumbnailresizename;
                    response.ImageURL = _SiteURL + "/" + folderPathSite + "/" + Imageresizename;
                    response.BannerImage_URL = _SiteURL + "/" + folderPathSite + "/" + ImageBannerresizename;
                    response.IsSuccess = true;
                    response.ResponseMessage = "";

                    return response;
                }
                else
                {
                    response.IsSuccess = false;
                    response.ResponseMessage = "File Extension not supported";

                    return response;
                }
            }
            else
            {
                response.IsSuccess = false;
                response.ResponseMessage = "File Not found";

                return response;
            }



        }

        public static ImageResponse GetMultipartImage(
                                  HttpFileCollectionBase files, string fileKey, string folderPath,
                                  int thumbWidth, int thumbHeight,
                                  int imgWidth, int imgHeight,
                                  string folderPathSite,
                                  bool deleteOriginal = false, bool GenThumbnail = true,
                                  bool GenImage = true, bool GenBanner = false)
        {

            string _SiteRoot = WebConfigurationManager.AppSettings["SiteImgPath"];
            string _SiteURL = WebConfigurationManager.AppSettings["SiteImgURL"];


            var file = files.Count > 0 ? files[fileKey] : null;
            ImageResponse response = new ImageResponse();

            if (file != null && file.ContentLength > 0)
            {
                var fileName = Path.GetFileName(file.FileName);
                string extension = Path.GetExtension(file.FileName).ToLower();
                string[] arr = new string[] { ".png", ".jpg", ".jpeg", ".gif", ".bmp" };

                if (arr.Contains(extension))
                {
                    string _NewFileName = Guid.NewGuid() + extension;

                    string tempfilePath = _SiteRoot + @"\" + "TempImages" + @"\" + _NewFileName;
                    Helper.CreateDirectories(_SiteRoot + @"\" + "TempImages" + @"\");

                    string newFilePath = _SiteRoot + @"\" + folderPath + @"\";
                    Helper.CreateDirectories(_SiteRoot + @"\" + folderPath + @"\");


                    string strIamgeURLfordb = _SiteURL + "/" + folderPathSite + "/" + _NewFileName;

                    file.SaveAs(tempfilePath);
                    string thumbnailresizename = "";
                    string Imageresizename = "";
                    string ImageBannerresizename = "";
                    string imageresizenametmp = "";

                    if (GenThumbnail == true)
                    {
                        thumbnailresizename = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "_T_" + _NewFileName, thumbWidth, thumbHeight);
                    }

                    if (GenImage == true)
                    {
                        //Scale up the image 
                        //imageresizenametmp = ResizeImage.ScaleImage(tempfilePath, tempfilePath, "_S_" + _NewFileName, 650, 650);

                        Imageresizename = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "_A_" + _NewFileName, imgWidth, imgHeight);
                        //Imageresizename = ResizeImage.CropImage(tempfilePath , newFilePath, "_A_" + imageresizenametmp, 0, 50, 640, 360);
                    }

                    if (GenBanner == true)
                    {
                        //Banner Image (event listing)
                        ImageBannerresizename = ResizeImage.CropImage(tempfilePath, newFilePath, "_B_" + imageresizenametmp, 0, 100, 640, 270);
                    }


                    if (deleteOriginal == true)
                    {
                        if (File.Exists(tempfilePath))
                        {
                            File.Delete(tempfilePath);
                        }
                    }


                    response.ThumbnailURL = _SiteURL + "/" + folderPathSite + "/" + thumbnailresizename;
                    response.ImageURL = _SiteURL + "/" + folderPathSite + "/" + Imageresizename;
                    response.BannerImage_URL = _SiteURL + "/" + folderPathSite + "/" + ImageBannerresizename;
                    response.IsSuccess = true;
                    response.ResponseMessage = "";

                    return response;
                }
                else
                {
                    response.IsSuccess = false;
                    response.ResponseMessage = "File Extension not supported";

                    return response;
                }
            }
            else
            {
                response.IsSuccess = false;
                response.ResponseMessage = "File Not found";


                return response;
            }



        }

        public static ImageResponse GetMultipartImageWithIndex(
                       HttpFileCollection files, string fileKey, string folderPath,
                       int thumbWidth, int thumbHeight,
                       int imgWidth, int imgHeight,
                       string folderPathSite,
                       int index,
                       bool deleteOriginal = false, bool GenThumbnail = true,
                       bool GenThumbnail2 = false,
                       bool GenImage = true, bool GenBanner = false)
        {

            string _SiteRoot = WebConfigurationManager.AppSettings["SiteImgPath"];
            string _SiteURL = WebConfigurationManager.AppSettings["SiteImgURL"];


            var file = files[index];

            ImageResponse response = new ImageResponse();

            if (file != null && file.ContentLength > 0)
            {
                var fileName = Path.GetFileName(file.FileName);
                string extension = Path.GetExtension(file.FileName).ToLower();
                string[] arr = new string[] { ".png", ".jpg", ".jpeg", ".gif", ".bmp" };

                if (arr.Contains(extension))
                {
                    string _NewFileName = Guid.NewGuid() + extension;

                    string tempfilePath = _SiteRoot + @"\" + "TempImages" + @"\" + _NewFileName;
                    Helper.CreateDirectories(_SiteRoot + @"\" + "TempImages" + @"\");

                    string newFilePath = _SiteRoot + @"\" + folderPath + @"\";
                    Helper.CreateDirectories(_SiteRoot + @"\" + folderPath + @"\");


                    string strIamgeURLfordb = _SiteURL + "/" + folderPathSite + "/" + _NewFileName;

                    file.SaveAs(tempfilePath);
                    string thumbnailresizename = "";
                    string thumbnailresizename2 = "";
                    string Imageresizename = "";
                    string ImageBannerresizename = "";
                    string imageresizenametmp = "";

                    if (GenThumbnail == true)
                    {
                        thumbnailresizename = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "_T_" + _NewFileName, thumbWidth, thumbHeight);
                    }

                    //if (GenThumbnail2 == true)
                    //{
                    //    //thumbnailresizename2 = ResizeImage.Resize_Image_Thumb_fixed(tempfilePath, newFilePath, "_T2_" + _NewFileName, thumbWidth2, thumbHeight2);
                    //    thumbnailresizename2 = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "_T2_" + _NewFileName, thumbWidth2, thumbHeight2);
                    //}

                    if (GenImage == true)
                    {
                        //Scale up the image 
                        //imageresizenametmp = ResizeImage.ScaleImage(tempfilePath, tempfilePath, "_S_" + _NewFileName, 650, 650);

                        Imageresizename = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "_A_" + _NewFileName, imgWidth, imgHeight);
                        //Imageresizename = ResizeImage.CropImage(tempfilePath , newFilePath, "_A_" + imageresizenametmp, 0, 50, 640, 360);
                    }

                    if (GenBanner == true)
                    {
                        //Banner Image (event listing)
                        ImageBannerresizename = ResizeImage.CropImage(tempfilePath, newFilePath, "_B_" + imageresizenametmp, 0, 100, 640, 270);
                    }


                    if (deleteOriginal == true)
                    {
                        if (File.Exists(tempfilePath))
                        {
                            File.Delete(tempfilePath);
                        }
                    }

                    response.ThumbnailURL2 = _SiteURL + "/" + folderPathSite + "/" + thumbnailresizename2;
                    response.ThumbnailURL = _SiteURL + "/" + folderPathSite + "/" + thumbnailresizename;
                    response.ImageURL = _SiteURL + "/" + folderPathSite + "/" + Imageresizename;

                    response.BannerImage_URL = _SiteURL + "/" + folderPathSite + "/" + ImageBannerresizename;
                    response.IsSuccess = true;
                    response.ResponseMessage = "";

                    return response;
                }
                else
                {
                    response.IsSuccess = false;
                    response.ResponseMessage = "File Extension not supported";

                    return response;
                }
            }
            else
            {
                response.IsSuccess = false;
                response.ResponseMessage = "File Not found";

                return response;
            }



        }

        //[HttpPost]
        //[Route("api/v1/Assets/AddAssetVideo")]
        //public async Task<HttpResponseMessage> AddAssetVideo()
        //{
        //    try
        //    {

        //        var httpContext = (HttpContextWrapper)Request.Properties["MS_HttpContext"];

        //        if (httpContext.Request.Form["UserID"] == "")
        //        {
        //            return Request.CreateResponse(HttpStatusCode.OK, JsonResponse.GetResponse(ResponseCode.Info, "Please provide UserID"));
        //        }


        //        _AssetsRepo = new GenericRepository<Assets>(_unitOfWork);
        //        _UsersRepo = new GenericRepository<Users>(_unitOfWork);
        //        _PostsRepo = new GenericRepository<Posts>(_unitOfWork);

        //        int userId = Convert.ToInt16(httpContext.Request.Form["UserID"]);


        //        var entity = _UsersRepo.Repository.Get(p => p.UserID == userId);


        //        //Check whether user exists
        //        if (entity == null)
        //        {
        //            return Request.CreateResponse(HttpStatusCode.OK,
        //                JsonResponse.GetResponse(ResponseCode.Info, Response.UserNotFound));
        //        }


        //        //Check whether the image file is provided
        //        if (HttpContext.Current.Request.Files.Count == 0)
        //        {
        //            return Request.CreateResponse(HttpStatusCode.OK,
        //                JsonResponse.GetResponse(ResponseCode.Info, "Video file is not provided", "UserData"));
        //        }

        //        var imgResponse = MultipartFiles.GetVideo(HttpContext.Current.Request.Files, "Video", userId.ToString());

        //        // Check whether the image file is created successfully
        //        if (!imgResponse.IsSuccess)
        //        {
        //            return Request.CreateResponse(HttpStatusCode.OK,
        //                JsonResponse.GetResponse(ResponseCode.Info, imgResponse.ResponseMessage));
        //        }

        //        //_unitOfWork.StartTransaction();

        //        Assets _Assets = new Assets();

        //        _Assets.AssetType = EPostType.Video.ToString();
        //        _Assets.ThumbnailURL = imgResponse.ThumbnailURL;
        //        _Assets.AssetURL = imgResponse.ImageURL;
        //        _Assets.CreatedDate = DateTime.Now;
        //        _Assets.RecordStatus = RecordStatus.Active.ToString();
        //        _Assets.UserID = userId;
        //        _Assets.AssetSort = 0;

        //        _AssetsRepo.Repository.Add(_Assets);

        //        //Adding posts
        //        var _NextSort = _PostsRepo.Repository.GetAll(p => p.UserID == userId).OrderByDescending(p => p.PostSort).FirstOrDefault().PostSort.ToString();

        //        Posts _Posts = new Posts();
        //        _Posts.AssetsID = _Assets.AssetsID;
        //        _Posts.UserID = userId;
        //        _Posts.PostType = EPostType.Image.ToString();
        //        _Posts.RecordStatus = RecordStatus.Active.ToString();
        //        _Posts.CreatedDate = DateTime.Now;
        //        _Posts.PostSort = Convert.ToInt16(_NextSort) + 1;

        //        _PostsRepo.Repository.Add(_Posts);

        //        //  _unitOfWork.Commit();


        //        Dictionary<string, string> _dic = new Dictionary<string, string>();
        //        _dic.Add("AssetID", _Assets.AssetsID.ToString());
        //        _dic.Add("ThumbnailURL", _SiteImgURL + _Assets.ThumbnailURL);

        //        return Request.CreateResponse(HttpStatusCode.OK, JsonResponse.GetResponse(ResponseCode.Success, _dic, "Assets"));

        //    }
        //    catch (Exception ex)
        //    {
        //        //if (_ApiLogger==true) LogHelper.CreateLog(ex);
        //        return Request.CreateResponse(HttpStatusCode.OK, JsonResponse.GetResponse(ResponseCode.Info, ex.Message));

        //    }
        //}

        //public static ImageResponse GetMultipartImage2(
        //                          HttpFileCollection files, string fileKey, string folderPath,
        //                          int thumbWidth, int thumbHeight,
        //                          int imgWidth, int imgHeight,
        //                          string folderPathSite, string _Filename,
        //                          bool deleteOriginal = false, bool GenThumbnail = false,
        //                          bool GenImage = true, bool GenBanner = false)
        //{

        //    string _SiteRoot = WebConfigurationManager.AppSettings["SiteImgPath"];
        //    string _SiteURL = WebConfigurationManager.AppSettings["SiteImgURL"];


        //    var file = files.Count > 0 ? files[fileKey] : null;
        //    ImageResponse response = new ImageResponse();

        //    if (file != null && file.ContentLength > 0)
        //    {
        //        var fileName = Path.GetFileName(file.FileName);
        //        string extension = Path.GetExtension(file.FileName).ToLower();
        //        string[] arr = new string[] { ".png", ".jpg", ".jpeg", ".gif", ".bmp" };

        //        if (arr.Contains(extension))
        //        {
        //            string _NewFileName = Guid.NewGuid() + extension;

        //            string tempfilePath = _SiteRoot + @"\" + "TempImages" + @"\" + _Filename;
        //            Helper.CreateDirectories(_SiteRoot + @"\" + "TempImages" + @"\");

        //            string newFilePath = _SiteRoot + @"\" + folderPath + @"\";
        //            Helper.CreateDirectories(_SiteRoot + @"\" + folderPath + @"\");


        //            string strIamgeURLfordb = _SiteURL + "/" + folderPathSite + "/" + _Filename;

        //            file.SaveAs(tempfilePath);
        //            string thumbnailresizename = "";
        //            string Imageresizename = "";
        //            string ImageBannerresizename = "";
        //            string imageresizenametmp = "";

        //            if (GenThumbnail == true)
        //            {
        //                thumbnailresizename = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, "T_" + _Filename, thumbWidth, thumbHeight);
        //            }

        //            if (GenImage == true)
        //            {
        //                //Scale up the image 
        //                //imageresizenametmp = ResizeImage.ScaleImage(tempfilePath, tempfilePath, "_S_" + _NewFileName, 650, 650);

        //                Imageresizename = ResizeImage.Resize_Image_Thumb(tempfilePath, newFilePath, _Filename, imgWidth, imgHeight);
        //                //Imageresizename = ResizeImage.CropImage(tempfilePath , newFilePath, "_A_" + imageresizenametmp, 0, 50, 640, 360);
        //            }

        //            if (GenBanner == true)
        //            {
        //                //Banner Image (event listing)
        //                ImageBannerresizename = ResizeImage.CropImage(tempfilePath, newFilePath, "_B_" + imageresizenametmp, 0, 100, 640, 270);
        //            }


        //            if (deleteOriginal == true)
        //            {
        //                if (File.Exists(tempfilePath))
        //                {
        //                    File.Delete(tempfilePath);
        //                }
        //            }


        //            response.ThumbnailURL = folderPathSite + "/" + thumbnailresizename;
        //            response.ImageURL = folderPathSite + "/" + Imageresizename;
        //            response.BannerImage_URL = folderPathSite + "/" + ImageBannerresizename;
        //            response.IsSuccess = true;
        //            response.ResponseMessage = "";

        //            return response;
        //        }
        //        else
        //        {
        //            response.IsSuccess = false;
        //            response.ResponseMessage = "File Extension not supported";

        //            return response;
        //        }
        //    }
        //    else
        //    {
        //        response.IsSuccess = false;
        //        response.ResponseMessage = "File Not found";

        //        return response;
        //    }



        //}


        public static ImageResponse GetVideo(HttpFileCollection files, string fileKey, string folderPath)
        {
            ImageResponse response = new ImageResponse();

            var file = files.Count > 0 ? files[fileKey] : null;
            if (file != null && file.ContentLength > 0)
            {
                var fileName = Path.GetFileName(file.FileName);
                var extension = Path.GetExtension(file.FileName).ToLower();
                string videoName = Guid.NewGuid() + extension;

                string currentYear = DateTime.Now.Year.ToString();
                string currentMonth = DateTime.Now.Month.ToString();

                string VideoPath = ConfigurationManager.AppSettings["SiteImgPath"].ToString() + @"\" + folderPath + "\\Videos\\";
                string VideoUrl = ConfigurationManager.AppSettings["SiteImgURL"].ToString() + "/" + folderPath + "/Videos/" + videoName;

                if (!Directory.Exists(VideoPath))
                {
                    Directory.CreateDirectory(VideoPath);
                }
                file.SaveAs(VideoPath + videoName);



                response.ThumbnailURL = "/" + folderPath + "/Videos/" + videoName;
                response.ImageURL = "/" + folderPath + "/Videos/" + videoName;
                response.IsSuccess = true;
                response.ResponseMessage = "";

                return response;
            }
            else
            {
                response.IsSuccess = false;
                response.ResponseMessage = "";
                return response;
            }
        }

        public static ResumeResponse SaveResume(HttpFileCollectionBase files, string fileKey, string folderPath)
        {

            var response = new ResumeResponse();

            try
            {
                var file = files.Count > 0 ? files[fileKey] : null;
                if (file != null)
                {
                    var fileName = Path.GetFileName(file.FileName);
                    var extension = Path.GetExtension(file.FileName).ToLower();
                    string videoName = Guid.NewGuid() + extension;

                    string currentYear = DateTime.Now.Year.ToString();
                    string currentMonth = DateTime.Now.Month.ToString();

                    string ResumePath = ConfigurationManager.AppSettings["SiteImgPath"].ToString() + @"\" + folderPath + "\\Resumes\\";
                    string ResumeUrl = ConfigurationManager.AppSettings["SiteImgURL"].ToString() + "/" + folderPath + "/Resumes/" + videoName;

                    if (!Directory.Exists(ResumePath))
                    {
                        Directory.CreateDirectory(ResumePath);
                    }
                    file.SaveAs(ResumePath + videoName);

                    response.Resume = fileName;
                    response.ResumeUrl = ResumeUrl;
                    response.IsSuccess = true;
                    response.ResponseMessage = "";

                    return response;
                }
                else
                {
                    response.IsSuccess = false;
                    response.ResponseMessage = "";
                    return response;
                }
            }
            catch (Exception ex)
            {

                LogHelper.CreateLog(ex);
                response.IsSuccess = false;
                response.ResponseMessage = ex.Message;
                return response;
            }
        }

    }
    public class ImageResponse
    {
        public string ThumbnailURL { get; set; }

        public string ThumbnailURL2 { get; set; }


        public string ImageURL { get; set; }

        public string BannerImage_URL { get; set; }

        public bool IsSuccess { get; set; }

        public string ResponseMessage { get; set; }
    }

    public class ResumeResponse
    {
        public string Resume { get; set; }
        public string ResumeUrl { get; set; }
        public bool IsSuccess { get; set; }
        public string ResponseMessage { get; set; }
    }

}
