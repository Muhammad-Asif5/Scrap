

// Load the credentials from your JSON key file or from Database
GoogleCredential credential = GoogleCredential.FromFile("your-credentials.json")
    .CreateScoped(AndroidPublisherService.Scope.Androidpublisher);