﻿using Google.Apis.AndroidPublisher.v3;
using Google.Apis.AndroidPublisher.v3.Data;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Auth.OAuth2.Flows;
using Google.Apis.Auth.OAuth2.Responses;
using Google.Apis.Services;
using Google.Apis.Util.Store;
using System.Threading;
using System.Web.Configuration;

namespace LawyerWatch.Library.ThirdPartyAPI.Google
{
    public static class GoogleAndroidPublisherServices
    {

        public static AndroidPublisherService GetAndroidPublisherService(TokenResponse token)
        {
            string clientId = WebConfigurationManager.AppSettings["CLIENT_ID"].ToString();
            string clientSecret = WebConfigurationManager.AppSettings["CLIENT_SECRET"].ToString();

            var service = new AndroidPublisherService(new BaseClientService.Initializer
            {
                HttpClientInitializer = new UserCredential(new GoogleAuthorizationCodeFlow(
                    new GoogleAuthorizationCodeFlow.Initializer
                    {
                        ClientSecrets = new ClientSecrets
                        {
                            ClientId = clientId,
                            ClientSecret = clientSecret
                        },
                        Scopes = new[] { AndroidPublisherService.Scope.Androidpublisher }
                    }),
                    "lawyerwatch-7d2f4",
                    token),
                ApplicationName = "LawyerWatch"
            });

            return service;
        }

        public static SubscriptionPurchase GetSubscriptionInfo(TokenResponse token, string packageName, string subscriptionId = "", string purchaseToken = "")
        {
            var service = GetAndroidPublisherService(token);

            var subscriptionStatusRequest = service.Purchases.Subscriptions.Get(
                packageName: packageName,
                subscriptionId: subscriptionId,
                token: purchaseToken
            );
            var subscriptionPurchase = subscriptionStatusRequest.Execute();

            return subscriptionPurchase;
        }
        public static SubscriptionPurchaseV2 GetSubscriptionV2Info(TokenResponse token, string packageName, string purchaseToken)
        {
            var service = GetAndroidPublisherService(token);

            var subscriptionStatusRequest = service.Purchases.Subscriptionsv2.Get(
                packageName: packageName,
                token: purchaseToken
            );
            var subscriptionPurchase = subscriptionStatusRequest.Execute();

            return subscriptionPurchase;
        }


        #region Generate Google OAuth2 Token 

        public static TokenResponse GoogleOAuth2Token(string code)
        {
            TokenResponse token = new TokenResponse();
            string clientId = WebConfigurationManager.AppSettings["CLIENT_ID"].ToString();
            string clientSecret = WebConfigurationManager.AppSettings["CLIENT_SECRET"].ToString();
            string redirectUri = WebConfigurationManager.AppSettings["GOOGLE_REDIRECT_URI"].ToString();
            string SiteImgPath = WebConfigurationManager.AppSettings["SiteImgPath"].ToString();

            GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow(new GoogleAuthorizationCodeFlow.Initializer
            {
                ClientSecrets = new ClientSecrets
                {
                    ClientId = clientId,
                    ClientSecret = clientSecret
                },
                Scopes = new[] { AndroidPublisherService.Scope.Androidpublisher },
                DataStore = new FileDataStore(SiteImgPath + "\\credentail", true),
            });

            string authorizationCode = code;
            token = flow.ExchangeCodeForTokenAsync("001", authorizationCode, redirectUri, CancellationToken.None).Result;
            return token;
        }

        public static string GoogleOAuth2URI()
        {
            // LogHelper.CreateLog("GoogleOAuth2URI Method", ErrorType.GoogleSubscription);
            string clientId = WebConfigurationManager.AppSettings["CLIENT_ID"].ToString();
            string clientSecret = WebConfigurationManager.AppSettings["CLIENT_SECRET"].ToString();
            string redirectUri = WebConfigurationManager.AppSettings["GOOGLE_REDIRECT_URI"].ToString();
            string SiteImgPath = WebConfigurationManager.AppSettings["SiteImgPath"].ToString();

            GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow(new GoogleAuthorizationCodeFlow.Initializer
            {
                ClientSecrets = new ClientSecrets
                {
                    ClientId = clientId,
                    ClientSecret = clientSecret
                },
                Scopes = new[] { AndroidPublisherService.Scope.Androidpublisher },
                //Scopes = new[] { "https://www.googleapis.com/auth/androidpublisher" },
            });

            dynamic authorizationUrl = flow.CreateAuthorizationCodeRequest(redirectUri).Build();
            return authorizationUrl.ToString();
        }

        #endregion




    }
}
